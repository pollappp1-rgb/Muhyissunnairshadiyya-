import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { onValue, ref, set } from "firebase/database";
import { db } from "./firebase";
import { seedData } from "./seed";
import { uid } from "./utils";
import type { Route, SiteData, TickerItem } from "./types";

const LS_KEY = "muhyissunna-data-v2";
const AUTH_KEY = "muhyissunna-admin-v1";
const LIKES_KEY = "muhyissunna-likes-v1";

export interface Toast {
  id: number;
  msg: string;
  kind: "success" | "error" | "info";
}

interface StoreCtx {
  data: SiteData;
  connected: boolean;
  dbError: string | null;
  route: Route;
  nav: (page: Route["page"], id?: string) => void;
  isAdmin: boolean;
  login: (u: string, p: string) => boolean;
  logout: () => void;
  toast: (msg: string, kind?: Toast["kind"]) => void;
  dismissToast: (id: number) => void;
  toasts: Toast[];
  setSection: <K extends keyof SiteData>(key: K, value: SiteData[K], silent?: boolean) => void;
  liked: (id: string) => boolean;
  toggleLike: (id: string) => void;
}

const PAGES: Route["page"][] = [
  "home", "works", "magazines", "gallery", "videos", "events", "notices",
  "awards", "committee", "forums", "report", "about", "admin",
];

function parseHash(): Route {
  const h = window.location.hash.replace(/^#\/?/, "");
  if (!h) return { page: "home" };
  const [p, id] = h.split("/");
  const page = PAGES.includes(p as Route["page"]) ? (p as Route["page"]) : "home";
  return { page, id: id || undefined };
}

const Ctx = createContext<StoreCtx | null>(null);

function asArray<T>(v: unknown): T[] {
  if (Array.isArray(v)) return v as T[];
  if (v && typeof v === "object") return Object.values(v) as T[];
  return [];
}

function normalizeTickerItems(raw: unknown, fallback: TickerItem[]): TickerItem[] {
  if (!raw) return fallback;
  return asArray<TickerItem | string>(raw)
    .map((it) => (typeof it === "string" ? { id: uid(), text: it, visible: true } : it))
    .filter((it): it is TickerItem => !!it && typeof (it as TickerItem).text === "string");
}

function mergeWithSeed(raw: Record<string, unknown> | null): SiteData {
  const s = seedData;
  if (!raw || typeof raw !== "object") return s;
  const rs = (raw.settings || {}) as Partial<SiteData["settings"]>;
  return {
    settings: {
      ...s.settings,
      ...rs,
      theme: { ...s.settings.theme, ...(rs.theme || {}) },
      popup: { ...s.settings.popup, ...(rs.popup || {}) },
      ticker: { ...s.settings.ticker, ...(rs.ticker || {}), items: normalizeTickerItems(rs.ticker?.items, s.settings.ticker.items) },
      auth: { ...s.settings.auth, ...(rs.auth || {}) },
    },
    homeLayout: raw.homeLayout ? asArray(raw.homeLayout) : s.homeLayout,
    homeButtons: raw.homeButtons ? asArray(raw.homeButtons) : s.homeButtons,
    categories: raw.categories ? asArray(raw.categories) : s.categories,
    publications: raw.publications ? asArray(raw.publications) : s.publications,
    magazines: raw.magazines ? asArray(raw.magazines) : s.magazines,
    albums: raw.albums ? asArray(raw.albums) : s.albums,
    videos: raw.videos ? asArray(raw.videos) : s.videos,
    events: raw.events ? asArray(raw.events) : s.events,
    notices: raw.notices ? asArray(raw.notices) : s.notices,
    awards: raw.awards ? asArray(raw.awards) : s.awards,
    members: raw.members ? asArray(raw.members) : s.members,
    forums: raw.forums ? asArray(raw.forums) : s.forums,
    complaints: raw.complaints ? asArray(raw.complaints) : s.complaints,
  };
}

function loadLocal(): SiteData | null {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    return mergeWithSeed(JSON.parse(raw) as Record<string, unknown>);
  } catch {
    return null;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SiteData>(() => loadLocal() || seedData);
  const [connected, setConnected] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [route, setRoute] = useState<Route>(() => parseHash());
  const [isAdmin, setIsAdmin] = useState<boolean>(() => sessionStorage.getItem(AUTH_KEY) === "1");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const seeded = useRef(false);
  const toastId = useRef(0);
  const offlineNoticed = useRef(false);

  // ---- realtime subscription -------------------------------------------
  useEffect(() => {
    const root = ref(db, "/");
    const unsub = onValue(
      root,
      (snap) => {
        const raw = snap.val() as Record<string, unknown> | null;
        if (raw === null && !seeded.current) {
          seeded.current = true;
          set(root, seedData).catch(() => undefined);
        }
        const merged = mergeWithSeed(raw);
        setData(merged);
        setDbError(null);
        try {
          localStorage.setItem(LS_KEY, JSON.stringify(raw || seedData));
        } catch {
          /* storage full — images too large for cache; ignore */
        }
        seeded.current = true;
      },
      (err) => {
        setDbError(err.message || "permission_denied");
        if (!offlineNoticed.current) {
          offlineNoticed.current = true;
        }
      }
    );
    const conn = ref(db, ".info/connected");
    const unsubConn = onValue(conn, (s) => setConnected(s.val() === true));
    return () => {
      unsub();
      unsubConn();
    };
  }, []);

  // ---- toasts -------------------------------------------------------------
  const dismissToast = useCallback((id: number) => {
    setToasts((ts) => ts.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback(
    (msg: string, kind: Toast["kind"] = "success") => {
      const id = ++toastId.current;
      setToasts((ts) => [...ts.slice(-3), { id, msg, kind }]);
      window.setTimeout(() => dismissToast(id), 3600);
    },
    [dismissToast]
  );

  // ---- writes ---------------------------------------------------------------
  const setSection = useCallback(
    <K extends keyof SiteData>(key: K, value: SiteData[K], silent = false) => {
      setData((prev) => {
        const next = { ...prev, [key]: value };
        try {
          localStorage.setItem(LS_KEY, JSON.stringify(next));
        } catch {
          /* ignore */
        }
        return next;
      });
      set(ref(db, String(key)), value as unknown).catch((e: Error) => {
        setDbError(e.message || "write failed");
        if (!silent)
          toast("Saved locally — Firebase blocked the sync. Check Realtime Database rules in Admin → Settings.", "error");
      });
    },
    [toast]
  );

  // ---- routing (hash based — every page & item has its own shareable URL) -----
  const nav = useCallback((page: Route["page"], id?: string) => {
    const hash = `#/${page}${id ? `/${id}` : ""}`;
    if (window.location.hash === hash) {
      setRoute({ page, id });
      requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }));
    } else {
      window.location.hash = hash; // hashchange listener updates state + scrolls
    }
  }, []);

  useEffect(() => {
    const fn = () => {
      setRoute(parseHash());
      requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }));
    };
    window.addEventListener("hashchange", fn);
    return () => window.removeEventListener("hashchange", fn);
  }, []);

  // ---- auth ---------------------------------------------------------------------
  const login = useCallback(
    (u: string, p: string) => {
      const ok = u.trim() === data.settings.auth.username && p === data.settings.auth.password;
      if (ok) {
        sessionStorage.setItem(AUTH_KEY, "1");
        setIsAdmin(true);
      }
      return ok;
    },
    [data.settings.auth]
  );

  const logout = useCallback(() => {
    sessionStorage.removeItem(AUTH_KEY);
    setIsAdmin(false);
  }, []);

  // ---- likes ------------------------------------------------------------------
  const readLikes = (): string[] => {
    try {
      return JSON.parse(localStorage.getItem(LIKES_KEY) || "[]") as string[];
    } catch {
      return [];
    }
  };

  const liked = useCallback((id: string) => readLikes().includes(id), []);

  const toggleLike = useCallback(
    (id: string) => {
      const list = readLikes();
      const has = list.includes(id);
      const next = has ? list.filter((x) => x !== id) : [...list, id];
      localStorage.setItem(LIKES_KEY, JSON.stringify(next));
      const pubs = data.publications.map((p) =>
        p.id === id ? { ...p, likes: Math.max(0, (p.likes || 0) + (has ? -1 : 1)) } : p
      );
      setSection("publications", pubs, true);
    },
    [data.publications, setSection]
  );

  const value = useMemo<StoreCtx>(
    () => ({
      data,
      connected,
      dbError,
      route,
      nav,
      isAdmin,
      login,
      logout,
      toast,
      dismissToast,
      toasts,
      setSection,
      liked,
      toggleLike,
    }),
    [data, connected, dbError, route, nav, isAdmin, login, logout, toast, dismissToast, toasts, setSection, liked, toggleLike]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSite(): StoreCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useSite must be used inside StoreProvider");
  return ctx;
}
