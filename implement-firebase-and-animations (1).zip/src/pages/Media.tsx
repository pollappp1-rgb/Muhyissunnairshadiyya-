import { useState } from "react";
import { ArrowLeft, CalendarDays, Clapperboard, Download, Eye, Images, Newspaper, Play } from "lucide-react";
import { Eyebrow, Reveal, SplitText } from "../components/anim";
import { Btn, Chip, EmptyState, ImgBox, Lightbox, ShareBtn } from "../components/ui";
import { useSite } from "../store";
import { fmtDate, isDataUrl, youtubeId, ytThumb } from "../utils";

function Head({ eyebrow, title, sub }: { eyebrow: string; title: string; sub: string }) {
  return (
    <>
      <Eyebrow>{eyebrow}</Eyebrow>
      <Reveal delay={80}>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          <SplitText text={title} charDelay={30} startDelay={150} />
        </h1>
      </Reveal>
      <Reveal delay={160}>
        <p className="mt-3 max-w-2xl tx-soft">{sub}</p>
      </Reveal>
    </>
  );
}

function NotFound({ label, back }: { label: string; back: () => void }) {
  return (
    <main className="mx-auto max-w-3xl px-4 py-24 text-center">
      <p className="font-display text-6xl font-black tx-faint">404</p>
      <p className="mt-4 tx-soft">This {label} could not be found — it may have been removed.</p>
      <Btn className="mt-8" variant="outline" onClick={back}>Go back</Btn>
    </main>
  );
}

/* ================================================================== */
export function MagazinesPage() {
  const { data, route, nav, setSection } = useSite();
  const mags = data.magazines.filter((m) => m.visible);
  const open = mags.find((m) => m.id === route.id);

  const bumpDownloads = (id: string) => {
    setSection("magazines", data.magazines.map((m) => (m.id === id ? { ...m, downloads: (m.downloads || 0) + 1 } : m)), true);
  };

  if (route.id) {
    if (!open) return <NotFound label="issue" back={() => nav("magazines")} />;
    return (
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Btn variant="ghost" size="sm" onClick={() => nav("magazines")}>
          <ArrowLeft size={15} /> All issues
        </Btn>
        <div className="mt-8 grid items-start gap-8 sm:grid-cols-[220px_1fr]">
          <Reveal>
            <div className="overflow-hidden rounded-2xl border-[5px] border-[var(--surface)] shadow-xl">
              <ImgBox src={open.cover} alt={open.title} className="aspect-[3/4] w-full" />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div>
              <Chip>{open.issue}</Chip>
              <h1 className="mt-3 font-display text-4xl font-bold sm:text-5xl">
                <SplitText text={open.title} charDelay={24} startDelay={150} />
              </h1>
              <div className="mt-2 flex items-center gap-1.5 text-sm tx-faint">
                <CalendarDays size={14} /> {fmtDate(open.date)}
              </div>
              <p className="mt-4 text-sm leading-relaxed tx-soft">{open.description}</p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                {open.pdf ? (
                  isDataUrl(open.pdf) ? (
                    <a
                      href={open.pdf}
                      download={`${open.title}-${open.issue}.pdf`}
                      onClick={() => bumpDownloads(open.id)}
                      className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold tx-on transition hover:-translate-y-0.5 hover:shadow-lg"
                    >
                      <Download size={16} /> Download PDF
                    </a>
                  ) : (
                    <a
                      href={open.pdf}
                      target="_blank"
                      rel="noreferrer"
                      onClick={() => bumpDownloads(open.id)}
                      className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold tx-on transition hover:-translate-y-0.5 hover:shadow-lg"
                    >
                      <Newspaper size={16} /> Read / Download PDF
                    </a>
                  )
                ) : (
                  <span className="rounded-full border border-dashed line px-5 py-3 text-sm tx-faint">PDF will be attached soon by the admin</span>
                )}
                <ShareBtn title={`${open.title} · ${open.issue}`} path={`/magazines/${open.id}`} />
              </div>
              <div className="mt-4 text-xs tx-faint">{open.downloads} downloads so far</div>
            </div>
          </Reveal>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Head eyebrow="The Magazine" title="Digital issues" sub="Every issue of the association magazine — open one to read online, download the PDF or share it." />
      {mags.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Newspaper size={24} />} title="No magazines yet" sub="The first issue is on its way." /></div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
          {mags.map((m, i) => (
            <Reveal key={m.id} delay={(i % 4) * 80}>
              <button onClick={() => nav("magazines", m.id)} className="card-lift group w-full text-left">
                <div className="img-zoom overflow-hidden rounded-2xl border-[5px] border-[var(--surface)] shadow-xl">
                  <ImgBox src={m.cover} alt={m.title} className="aspect-[3/4] w-full" />
                </div>
                <div className="mt-3 font-display text-lg font-bold leading-tight">{m.title}</div>
                <div className="mt-0.5 text-xs tx-faint">{m.issue}</div>
                <div className="mt-1 flex items-center gap-1 text-[11px] tx-faint"><Download size={11} /> {m.downloads} downloads</div>
              </button>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}

/* ================================================================== */
export function GalleryPage() {
  const { data, route, nav } = useSite();
  const albums = data.albums.filter((a) => a.visible);
  const [light, setLight] = useState<number | null>(null);
  const album = albums.find((a) => a.id === route.id);

  if (album) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Btn variant="ghost" size="sm" onClick={() => nav("gallery")}>
            <ArrowLeft size={15} /> All albums
          </Btn>
          <ShareBtn title={album.title} path={`/gallery/${album.id}`} />
        </div>
        <div className="mt-4">
          <Head eyebrow={fmtDate(album.date)} title={album.title} sub={`${album.images.length} photographs from the archive.`} />
        </div>
        <div className="mt-10 columns-2 gap-4 sm:columns-3 [&>*]:mb-4">
          {album.images.map((img, i) => (
            <button key={i} onClick={() => setLight(i)} className="card-lift img-zoom block w-full overflow-hidden rounded-2xl">
              <img src={img} alt="" loading="lazy" className="w-full object-cover" />
            </button>
          ))}
        </div>
        {light !== null && <Lightbox images={album.images} index={light} onClose={() => setLight(null)} onNav={setLight} />}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Head eyebrow="Event Gallery" title="Photo albums" sub="Every program has its own album — open one to walk through the moments." />
      {albums.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Images size={24} />} title="No albums yet" sub="Photos from the next event will appear here." /></div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-5 lg:grid-cols-4">
          {albums.map((a, i) => (
            <Reveal key={a.id} delay={(i % 4) * 80}>
              <button onClick={() => nav("gallery", a.id)} className="card-lift group img-zoom relative w-full overflow-hidden rounded-[1.6rem] text-left">
                <ImgBox src={a.cover} alt={a.title} className="aspect-[4/5] w-full" />
                <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
                <span className="absolute left-3 top-3 rounded-full bg-black/45 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur">
                  <Images size={11} className="mr-1 inline" /> {a.images.length}
                </span>
                <span className="absolute inset-x-0 bottom-0 p-5 text-white">
                  <span className="block font-display text-lg font-bold leading-snug">{a.title}</span>
                  <span className="mt-0.5 block text-xs opacity-75">{fmtDate(a.date)}</span>
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}

/* ================================================================== */
export function VideosPage() {
  const { data, route, nav, setSection } = useSite();
  const vids = data.videos.filter((v) => v.visible);
  const open = vids.find((v) => v.id === route.id);

  const bumpViews = (id: string) => {
    setSection("videos", data.videos.map((v) => (v.id === id ? { ...v, views: (v.views || 0) + 1 } : v)), true);
  };

  if (route.id) {
    if (!open) return <NotFound label="video" back={() => nav("videos")} />;
    return (
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Btn variant="ghost" size="sm" onClick={() => nav("videos")}>
          <ArrowLeft size={15} /> All videos
        </Btn>
        <Reveal>
          <div className="mt-8 overflow-hidden rounded-[2rem] bg-black shadow-2xl">
            {youtubeId(open.url) ? (
              <iframe
                className="aspect-video w-full"
                src={`https://www.youtube.com/embed/${youtubeId(open.url)}?autoplay=1&rel=0`}
                title={open.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <video className="aspect-video w-full" src={open.url} controls autoPlay />
            )}
          </div>
        </Reveal>
        <Reveal delay={100}>
          <div className="mt-6">
            <Chip>{open.category}</Chip>
            <h1 className="mt-2 font-display text-2xl font-bold sm:text-3xl">
              <SplitText text={open.title} charDelay={16} startDelay={150} />
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-4 text-xs tx-faint">
              <span>{fmtDate(open.date)}</span>
              <span className="flex items-center gap-1"><Eye size={12} /> {open.views} views</span>
            </div>
            <div className="mt-5">
              <ShareBtn title={open.title} path={`/videos/${open.id}`} />
            </div>
          </div>
        </Reveal>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Head eyebrow="Video Hub" title="Watch the campus" sub="Aftermovies, recitals, documentaries and talks — straight from the association media team." />
      {vids.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Clapperboard size={24} />} title="No videos yet" sub="The media team is editing the next one." /></div>
      ) : (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {vids.map((v, i) => (
            <Reveal key={v.id} delay={(i % 3) * 80}>
              <button
                onClick={() => {
                  bumpViews(v.id);
                  nav("videos", v.id);
                }}
                className="card-lift group w-full overflow-hidden rounded-[1.6rem] bg-[var(--surface)] text-left ring-line"
              >
                <div className="img-zoom relative">
                  <ImgBox src={v.thumbnail || ytThumb(v.url)} alt={v.title} className="aspect-video w-full" />
                  <span className="absolute inset-0 bg-black/10 transition group-hover:bg-black/25" />
                  <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/25 text-white backdrop-blur transition duration-300 group-hover:scale-110 group-hover:bg-[var(--primary)]">
                    <Play size={20} className="ml-0.5 fill-current" />
                  </span>
                </div>
                <div className="p-5">
                  <Chip>{v.category}</Chip>
                  <h3 className="mt-2 line-clamp-2 font-display text-lg font-bold leading-snug">{v.title}</h3>
                  <div className="mt-2 flex items-center justify-between text-xs tx-faint">
                    <span>{fmtDate(v.date)}</span>
                    <span className="flex items-center gap-1"><Eye size={12} /> {v.views}</span>
                  </div>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}
