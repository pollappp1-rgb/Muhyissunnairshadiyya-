import { useMemo, useState } from "react";
import { BookOpen, CalendarDays, Heart, Search, Sparkles, User } from "lucide-react";
import { Eyebrow, Reveal, SplitText } from "../components/anim";
import { Chip, CloseBtn, EmptyState, ImgBox, Modal } from "../components/ui";
import { useSite } from "../store";
import { cx, fmtDate, isArabic, paragraphs } from "../utils";
import type { Publication } from "../types";

function LikeBtn({ p, big = false }: { p: Publication; big?: boolean }) {
  const { liked, toggleLike } = useSite();
  const on = liked(p.id);
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        toggleLike(p.id);
      }}
      className={cx(
        "inline-flex items-center gap-1.5 rounded-full font-bold transition-all active:scale-90",
        big ? "border line px-5 py-2.5 text-sm" : "px-2.5 py-1.5 text-xs",
        on ? "text-red-500" : "tx-faint hover:text-red-400"
      )}
      aria-label="Like"
    >
      <Heart size={big ? 17 : 14} className={cx("transition-all", on && "fill-red-500 scale-110")} />
      {p.likes}
    </button>
  );
}

export default function WorksPage() {
  const { data, route } = useSite();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [readerId, setReaderId] = useState<string | undefined>(route.id);

  const cats = useMemo(() => {
    const names = new Set<string>();
    data.categories.forEach((c) => names.add(c.name));
    data.publications.forEach((p) => names.add(p.category));
    return ["All", ...names];
  }, [data.categories, data.publications]);

  const catColor = (n: string) => data.categories.find((c) => c.name === n)?.color;

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return data.publications
      .filter((p) => p.visible)
      .filter((p) => cat === "All" || p.category === cat)
      .filter(
        (p) =>
          !needle ||
          [p.title, p.author, p.excerpt, p.content, p.category].some((f) => f.toLowerCase().includes(needle))
      );
  }, [data.publications, q, cat]);

  const reader = data.publications.find((p) => p.id === readerId);

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Eyebrow>Student Creations</Eyebrow>
      <Reveal delay={80}>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          <SplitText text="Publications" charDelay={30} startDelay={150} />
        </h1>
      </Reveal>
      <Reveal delay={160}>
        <p className="mt-3 max-w-2xl tx-soft">
          Poems, stories, essays, articles and speeches — in Malayalam, English and Arabic. Tap a card to read, and show love with a like.
        </p>
      </Reveal>

      <Reveal delay={220}>
        <div className="mt-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full max-w-md">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 tx-faint" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search titles, authors, text…"
              className="w-full rounded-full border line bg-[var(--surface)] py-3 pl-11 pr-4 text-sm outline-none focus:border-[var(--primary)]"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={cx(
                  "rounded-full border px-4 py-2 text-xs font-bold uppercase tracking-wider transition",
                  cat === c ? "border-[var(--primary)] bg-primary tx-on" : "line tx-soft hover:tx"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </Reveal>

      {list.length === 0 ? (
        <div className="mt-12">
          <EmptyState icon={<BookOpen size={24} />} title="Nothing found" sub="Try a different search or category." />
        </div>
      ) : (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p, i) => (
            <Reveal key={p.id} delay={(i % 3) * 80}>
              <article
                onClick={() => setReaderId(p.id)}
                className="card-lift group cursor-pointer overflow-hidden rounded-[1.6rem] bg-[var(--surface)] ring-line"
              >
                {p.thumbnail && (
                  <div className="img-zoom relative">
                    <ImgBox src={p.thumbnail} alt={p.title} className="aspect-[16/10] w-full" />
                    <span className="absolute left-3 top-3 flex gap-2">
                      <Chip color={catColor(p.category)}>{p.category}</Chip>
                      {p.featured && (
                        <Chip color="#c9a24b"><Sparkles size={11} /> Featured</Chip>
                      )}
                    </span>
                  </div>
                )}
                <div className="p-5">
                  {!p.thumbnail && (
                    <div className="mb-2 flex flex-wrap gap-2">
                      <Chip color={catColor(p.category)}>{p.category}</Chip>
                      {p.featured && <Chip color="#c9a24b"><Sparkles size={11} /> Featured</Chip>}
                    </div>
                  )}
                  <h3 className={cx("line-clamp-2 font-display text-lg font-bold leading-snug", isArabic(p.title) && "font-ar text-right")} dir={isArabic(p.title) ? "rtl" : "ltr"}>
                    {p.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm tx-soft">{p.excerpt}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-xs font-semibold">{p.author}</span>
                    <LikeBtn p={p} />
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      )}

      {/* reader */}
      <Modal open={!!reader} onClose={() => setReaderId(undefined)} wide>
        {reader && (
          <div className="relative p-0">
            <CloseBtn onClick={() => setReaderId(undefined)} />
            {reader.thumbnail && <ImgBox src={reader.thumbnail} alt={reader.title} className="h-52 w-full rounded-t-[2rem] sm:h-64" />}
            <div className="p-6 sm:p-10">
              <div className="flex flex-wrap items-center gap-2">
                <Chip color={catColor(reader.category)}>{reader.category}</Chip>
                {reader.featured && <Chip color="#c9a24b"><Sparkles size={11} /> Featured</Chip>}
              </div>
              <h2 className={cx("mt-4 font-display text-2xl font-bold leading-snug sm:text-4xl", isArabic(reader.title) && "font-ar text-right")} dir={isArabic(reader.title) ? "rtl" : "ltr"}>
                <SplitText text={reader.title} charDelay={14} startDelay={120} />
              </h2>
              <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 border-b line pb-5 text-sm tx-soft">
                <span className="flex items-center gap-1.5"><User size={14} /> {reader.author}</span>
                <span className="flex items-center gap-1.5"><CalendarDays size={14} /> {fmtDate(reader.date)}</span>
              </div>
              <div className="mt-6 space-y-5 text-[15px] leading-[1.9] sm:text-base">
                {paragraphs(reader.content).map((para, i) => {
                  const ar = isArabic(para);
                  return (
                    <p
                      key={i}
                      dir={ar ? "rtl" : "ltr"}
                      className={cx(ar && "font-ar text-right text-lg", i === 0 && !ar && "dropcap", "whitespace-pre-line")}
                    >
                      {para}
                    </p>
                  );
                })}
              </div>
              <div className="mt-8 flex items-center justify-between border-t line pt-6">
                <span className="text-xs font-bold uppercase tracking-[0.2em] tx-faint">Appreciate this work</span>
                <LikeBtn p={reader} big />
              </div>
            </div>
          </div>
        )}
      </Modal>
    </main>
  );
}
