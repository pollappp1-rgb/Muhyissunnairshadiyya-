import { useState } from "react";
import {
  BadgeCheck, ChevronDown, Compass, Flag, Mail, MapPin, MessagesSquare, Phone, Send, Target, TriangleAlert,
} from "lucide-react";
import { Eyebrow, Reveal, SplitText } from "../components/anim";
import { Avatar, Btn, Chip, EmptyState, Field, SelectInput, TextArea, TextInput } from "../components/ui";
import { useSite } from "../store";
import { cx, timeAgo, todayISO, uid } from "../utils";

function Head({ eyebrow, title, sub }: { eyebrow: string; title: string; sub: string }) {
  return (
    <>
      <Eyebrow>{eyebrow}</Eyebrow>
      <Reveal delay={80}>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          <SplitText text={title} charDelay={30} startDelay={150} />
        </h1>
      </Reveal>
      <Reveal delay={160}>
        <p className="mt-3 max-w-2xl tx-soft">{sub}</p>
      </Reveal>
    </>
  );
}

/* ================================================================== */
export function CommitteePage() {
  const { data } = useSite();
  const members = data.members.filter((m) => m.visible);
  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <Head eyebrow="The Team" title="Association committee" sub="The students who keep Muhyissunna moving — programs, magazine, media and everything in between." />
      {members.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<BadgeCheck size={24} />} title="Committee coming soon" sub="The new panel will be announced shortly." /></div>
      ) : (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {members.map((m, i) => (
            <Reveal key={m.id} delay={(i % 4) * 80}>
              <article className="card-lift h-full rounded-[1.8rem] bg-[var(--surface)] p-7 text-center ring-line">
                <Avatar name={m.name} photo={m.photo} sizeClass="mx-auto h-24 w-24" textClass="text-2xl" />
                <h3 className="mt-5 font-display text-xl font-bold leading-tight">{m.name}</h3>
                <div className="mt-2"><Chip color="#0b6b4f">{m.role}</Chip></div>
                {m.bio && <p className="mt-3 text-sm leading-relaxed tx-faint">{m.bio}</p>}
              </article>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}

/* ================================================================== */
export function ForumsPage() {
  const { data, setSection, toast } = useSite();
  const topics = data.forums.slice().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const [openId, setOpenId] = useState<string | null>(topics[0]?.id || null);
  const [name, setName] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [shake, setShake] = useState(false);

  const submit = () => {
    if (!name.trim() || !subject.trim() || !message.trim()) {
      setShake(true);
      window.setTimeout(() => setShake(false), 500);
      toast("Please fill your name, subject and message.", "error");
      return;
    }
    setSection(
      "forums",
      [
        { id: uid(), name: name.trim(), subject: subject.trim(), message: message.trim(), date: todayISO(), status: "open", responses: [] },
        ...data.forums,
      ],
      true
    );
    setName("");
    setSubject("");
    setMessage("");
    toast("Topic posted — the admin team can reply here in real time.");
  };

  return (
    <main className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
      <Head eyebrow="Student Forums" title="Ask & discuss" sub="Start a topic with your name — the association team answers publicly so everyone benefits." />

      <div className="mt-10 grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <div className="grid content-start gap-4">
          {topics.length === 0 && (
            <EmptyState icon={<MessagesSquare size={24} />} title="No topics yet" sub="Be the first to start a discussion." />
          )}
          {topics.map((t, i) => {
            const open = openId === t.id;
            return (
              <Reveal key={t.id} delay={(i % 4) * 60}>
                <article className={cx("overflow-hidden rounded-[1.6rem] bg-[var(--surface)] ring-line transition", open && "ring-2 ring-[var(--primary)]")}>
                  <button onClick={() => setOpenId(open ? null : t.id)} className="flex w-full items-center gap-4 p-5 text-left">
                    <Avatar name={t.name} sizeClass="h-11 w-11" textClass="text-sm" />
                    <span className="min-w-0 flex-1">
                      <span className="line-clamp-1 font-display text-lg font-bold leading-snug">{t.subject}</span>
                      <span className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs tx-faint">
                        <span className="font-semibold">{t.name}</span> · {timeAgo(t.date)} · {t.responses.length}{" "}
                        {t.responses.length === 1 ? "reply" : "replies"}
                      </span>
                    </span>
                    <span className="flex flex-col items-end gap-2">
                      <Chip color={t.status === "open" ? "#0b6b4f" : "#6b7280"}>{t.status === "open" ? "Open" : "Closed"}</Chip>
                      <ChevronDown size={16} className={cx("tx-faint transition-transform duration-300", open && "rotate-180")} />
                    </span>
                  </button>
                  {open && (
                    <div className="fade-in border-t line px-5 py-5">
                      <p className="whitespace-pre-line text-sm leading-relaxed">{t.message}</p>
                      {t.responses.length > 0 && (
                        <div className="mt-5 space-y-3">
                          {t.responses.map((r, ri) => (
                            <div
                              key={ri}
                              className={cx(
                                "rounded-2xl p-4 text-sm",
                                r.admin ? "bg-[color-mix(in_srgb,var(--primary)_8%,transparent)]" : "soft-panel"
                              )}
                            >
                              <div className="mb-1 flex items-center gap-2 text-xs font-bold">
                                {r.admin ? (
                                  <span className="flex items-center gap-1 tx-primary">
                                    <BadgeCheck size={14} /> {r.by} · Association
                                  </span>
                                ) : (
                                  <span>{r.by}</span>
                                )}
                                <span className="font-normal tx-faint">{timeAgo(r.date)}</span>
                              </div>
                              <p className="leading-relaxed">{r.text}</p>
                            </div>
                          ))}
                        </div>
                      )}
                      {t.responses.length === 0 && (
                        <p className="mt-4 text-xs italic tx-faint">Awaiting a reply from the association team…</p>
                      )}
                    </div>
                  )}
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={140}>
          <div className={cx("sticky top-32 rounded-[1.8rem] bg-[var(--surface)] p-6 ring-line sm:p-7", shake && "shake")}>
            <h3 className="font-display text-xl font-bold">Start a new topic</h3>
            <p className="mt-1 text-sm tx-faint">Your name is required — it shows with your question.</p>
            <div className="mt-5 space-y-4">
              <Field label="Your name">
                <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Rashid M" />
              </Field>
              <Field label="Subject">
                <TextInput value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="What is it about?" />
              </Field>
              <Field label="Message">
                <TextArea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Write your question or idea…" />
              </Field>
              <Btn className="w-full" onClick={submit}>
                <Send size={16} /> Post to forum
              </Btn>
            </div>
          </div>
        </Reveal>
      </div>
    </main>
  );
}

/* ================================================================== */
export function ReportPage() {
  const { data, setSection, toast } = useSite();
  const [name, setName] = useState("");
  const [kind, setKind] = useState("Complaint");
  const [message, setMessage] = useState("");
  const [shake, setShake] = useState(false);

  const submit = () => {
    if (!name.trim() || !message.trim()) {
      setShake(true);
      window.setTimeout(() => setShake(false), 500);
      toast("Your name and message are required.", "error");
      return;
    }
    setSection(
      "complaints",
      [{ id: uid(), name: name.trim(), kind, message: message.trim(), date: todayISO(), read: false }, ...data.complaints],
      true
    );
    setName("");
    setMessage("");
    toast(`${kind} delivered to the admin panel — thank you for speaking up.`);
  };

  return (
    <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <Head eyebrow="Voice It" title="Report to the admin" sub="Complaints, suggestions and feedback land directly in the admin dashboard with your name and timestamp." />
      <Reveal delay={200}>
        <div className={cx("mt-10 rounded-[2rem] bg-[var(--surface)] p-6 ring-line sm:p-8", shake && "shake")}>
          <div className="mb-6 flex items-start gap-3 rounded-2xl bg-[color-mix(in_srgb,var(--accent)_12%,transparent)] p-4 text-sm leading-relaxed">
            <TriangleAlert size={18} className="mt-0.5 shrink-0 tx-accent" />
            <p>
              Reports are <strong>not anonymous</strong> — your name and time are shown to the admin team so they can follow up with you.
            </p>
          </div>
          <div className="space-y-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Your name">
                <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" />
              </Field>
              <Field label="Type">
                <SelectInput value={kind} onChange={(e) => setKind(e.target.value)}>
                  <option>Complaint</option>
                  <option>Suggestion</option>
                  <option>Feedback</option>
                  <option>Other</option>
                </SelectInput>
              </Field>
            </div>
            <Field label="Message">
              <TextArea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe the issue or idea clearly…"
                className="min-h-[150px]"
              />
            </Field>
            <Btn className="w-full sm:w-auto" onClick={submit}>
              <Flag size={15} /> Submit {kind.toLowerCase()}
            </Btn>
          </div>
        </div>
      </Reveal>
    </main>
  );
}

/* ================================================================== */
export function AboutPage() {
  const { data } = useSite();
  const s = data.settings;
  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <Head eyebrow="Who We Are" title="About the association" sub={s.tagline + "."} />

      <div className="mt-10 grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <Reveal>
          <div className="h-full rounded-[2rem] bg-[var(--surface)] p-7 ring-line sm:p-9">
            <h3 className="font-display text-2xl font-bold">
              {s.siteName} <span className="tx-accent">{s.siteUnit}</span>
            </h3>
            <div className="mt-4 space-y-4 text-[15px] leading-[1.85] tx-soft">
              {s.about.split(/\n+/).map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
          </div>
        </Reveal>
        <div className="grid content-start gap-5">
          <Reveal delay={100}>
            <div className="rounded-[2rem] bg-primary p-7 tx-on">
              <Target size={26} />
              <h4 className="mt-3 font-display text-lg font-bold">Vision</h4>
              <p className="mt-2 text-sm leading-relaxed opacity-90">{s.vision}</p>
            </div>
          </Reveal>
          <Reveal delay={180}>
            <div className="rounded-[2rem] bg-ink p-7 text-[var(--bg)]">
              <Compass size={26} className="tx-accent" />
              <h4 className="mt-3 font-display text-lg font-bold">Mission</h4>
              <p className="mt-2 text-sm leading-relaxed opacity-90">{s.mission}</p>
            </div>
          </Reveal>
        </div>
      </div>

      <Reveal delay={120}>
        <div className="mt-5 rounded-[2rem] bg-[var(--surface)] p-7 ring-line sm:p-9">
          <h3 className="font-display text-xl font-bold">Reach us</h3>
          <div className="mt-5 grid gap-4 sm:grid-cols-3">
            {s.email && (
              <a href={`mailto:${s.email}`} className="card-lift flex items-center gap-3 rounded-2xl soft-panel p-4">
                <Mail size={18} className="shrink-0 tx-primary" />
                <span className="min-w-0 truncate text-sm font-semibold">{s.email}</span>
              </a>
            )}
            {s.phone && (
              <a href={`tel:${s.phone}`} className="card-lift flex items-center gap-3 rounded-2xl soft-panel p-4">
                <Phone size={18} className="shrink-0 tx-primary" />
                <span className="min-w-0 truncate text-sm font-semibold">{s.phone}</span>
              </a>
            )}
            {s.address && (
              <div className="card-lift flex items-center gap-3 rounded-2xl soft-panel p-4">
                <MapPin size={18} className="shrink-0 tx-primary" />
                <span className="min-w-0 text-sm font-semibold">{s.address}</span>
              </div>
            )}
          </div>
        </div>
      </Reveal>
    </main>
  );
}
