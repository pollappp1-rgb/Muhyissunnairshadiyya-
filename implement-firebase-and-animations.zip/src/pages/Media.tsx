import { useState } from "react";
import { ArrowLeft, CalendarDays, Clapperboard, Download, Eye, Images, Newspaper, Play } from "lucide-react";
import { Eyebrow, Reveal, SplitText } from "../components/anim";
import { Btn, Chip, CloseBtn, EmptyState, ImgBox, Lightbox, Modal } from "../components/ui";
import { useSite } from "../store";
import { cx, fmtDate, isDataUrl, youtubeId, ytThumb } from "../utils";

function Head({ eyebrow, title, sub }: { eyebrow: string; title: string; sub: string }) {
  return (
    <>
      <Eyebrow>{eyebrow}</Eyebrow>
      <Reveal delay={80}>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          <SplitText text={title} charDelay={30} startDelay={150} />
        </h1>
      </Reveal>
      <Reveal delay={160}>
        <p className="mt-3 max-w-2xl tx-soft">{sub}</p>
      </Reveal>
    </>
  );
}

/* ================================================================== */
export function MagazinesPage() {
  const { data, route, setSection } = useSite();
  const mags = data.magazines.filter((m) => m.visible);
  const [openId, setOpenId] = useState<string | undefined>(route.id);
  const open = mags.find((m) => m.id === openId);

  const bumpDownloads = (id: string) => {
    setSection("magazines", data.magazines.map((m) => (m.id === id ? { ...m, downloads: (m.downloads || 0) + 1 } : m)), true);
  };

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Head eyebrow="The Magazine" title="Digital issues" sub="Every issue of the association magazine — read online or download the PDF and carry it with you." />
      {mags.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Newspaper size={24} />} title="No magazines yet" sub="The first issue is on its way." /></div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
          {mags.map((m, i) => (
            <Reveal key={m.id} delay={(i % 4) * 80}>
              <button onClick={() => setOpenId(m.id)} className="card-lift group w-full text-left">
                <div className="img-zoom overflow-hidden rounded-2xl border-[5px] border-[var(--surface)] shadow-xl">
                  <ImgBox src={m.cover} alt={m.title} className="aspect-[3/4] w-full" />
                </div>
                <div className="mt-3 font-display text-lg font-bold leading-tight">{m.title}</div>
                <div className="mt-0.5 text-xs tx-faint">{m.issue}</div>
                <div className="mt-1 flex items-center gap-1 text-[11px] tx-faint"><Download size={11} /> {m.downloads} downloads</div>
              </button>
            </Reveal>
          ))}
        </div>
      )}

      <Modal open={!!open} onClose={() => setOpenId(undefined)}>
        {open && (
          <div className="relative">
            <CloseBtn onClick={() => setOpenId(undefined)} />
            <div className="grid gap-6 sm:grid-cols-[180px_1fr]">
              <div className="overflow-hidden rounded-2xl shadow-lg">
                <ImgBox src={open.cover} alt={open.title} className="aspect-[3/4] w-full" />
              </div>
              <div>
                <Chip>{open.issue}</Chip>
                <h2 className="mt-3 font-display text-3xl font-bold">{open.title}</h2>
                <div className="mt-2 flex items-center gap-1.5 text-sm tx-faint"><CalendarDays size={14} /> {fmtDate(open.date)}</div>
                <p className="mt-4 text-sm leading-relaxed tx-soft">{open.description}</p>
                <div className="mt-6 flex flex-wrap items-center gap-3">
                  {open.pdf ? (
                    isDataUrl(open.pdf) ? (
                      <a
                        href={open.pdf}
                        download={`${open.title}-${open.issue}.pdf`}
                        onClick={() => bumpDownloads(open.id)}
                        className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold tx-on transition hover:-translate-y-0.5 hover:shadow-lg"
                      >
                        <Download size={16} /> Download PDF
                      </a>
                    ) : (
                      <a
                        href={open.pdf}
                        target="_blank"
                        rel="noreferrer"
                        onClick={() => bumpDownloads(open.id)}
                        className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-bold tx-on transition hover:-translate-y-0.5 hover:shadow-lg"
                      >
                        <Newspaper size={16} /> Read / Download PDF
                      </a>
                    )
                  ) : (
                    <span className="rounded-full border border-dashed line px-5 py-3 text-sm tx-faint">PDF will be attached soon by the admin</span>
                  )}
                  <span className="text-xs tx-faint">{open.downloads} downloads so far</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </main>
  );
}

/* ================================================================== */
export function GalleryPage() {
  const { data, route } = useSite();
  const albums = data.albums.filter((a) => a.visible);
  const [albumId, setAlbumId] = useState<string | undefined>(route.id);
  const [light, setLight] = useState<number | null>(null);
  const album = albums.find((a) => a.id === albumId);

  if (album) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <Btn variant="ghost" size="sm" onClick={() => setAlbumId(undefined)}>
          <ArrowLeft size={15} /> All albums
        </Btn>
        <div className="mt-4">
          <Head eyebrow={fmtDate(album.date)} title={album.title} sub={`${album.images.length} photographs from the archive.`} />
        </div>
        <div className="mt-10 columns-2 gap-4 sm:columns-3 [&>*]:mb-4">
          {album.images.map((img, i) => (
            <button key={i} onClick={() => setLight(i)} className="card-lift img-zoom block w-full overflow-hidden rounded-2xl">
              <img src={img} alt="" loading="lazy" className="w-full object-cover" />
            </button>
          ))}
        </div>
        {light !== null && (
          <Lightbox images={album.images} index={light} onClose={() => setLight(null)} onNav={setLight} />
        )}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Head eyebrow="Event Gallery" title="Photo albums" sub="Every program has its own album — tap to walk through the moments." />
      {albums.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Images size={24} />} title="No albums yet" sub="Photos from the next event will appear here." /></div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-5 lg:grid-cols-4">
          {albums.map((a, i) => (
            <Reveal key={a.id} delay={(i % 4) * 80}>
              <button onClick={() => setAlbumId(a.id)} className="card-lift group img-zoom relative w-full overflow-hidden rounded-[1.6rem] text-left">
                <ImgBox src={a.cover} alt={a.title} className="aspect-[4/5] w-full" />
                <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
                <span className="absolute left-3 top-3 rounded-full bg-black/45 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-white backdrop-blur">
                  <Images size={11} className="mr-1 inline" /> {a.images.length}
                </span>
                <span className="absolute inset-x-0 bottom-0 p-5 text-white">
                  <span className="block font-display text-lg font-bold leading-snug">{a.title}</span>
                  <span className="mt-0.5 block text-xs opacity-75">{fmtDate(a.date)}</span>
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}

/* ================================================================== */
export function VideosPage() {
  const { data, route, setSection } = useSite();
  const vids = data.videos.filter((v) => v.visible);
  const [openId, setOpenId] = useState<string | undefined>(route.id);
  const open = vids.find((v) => v.id === openId);

  const openVideo = (id: string) => {
    setOpenId(id);
    setSection("videos", data.videos.map((v) => (v.id === id ? { ...v, views: (v.views || 0) + 1 } : v)), true);
  };

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Head eyebrow="Video Hub" title="Watch the campus" sub="Aftermovies, recitals, documentaries and talks — straight from the association media team." />
      {vids.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Clapperboard size={24} />} title="No videos yet" sub="The media team is editing the next one." /></div>
      ) : (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {vids.map((v, i) => (
            <Reveal key={v.id} delay={(i % 3) * 80}>
              <button onClick={() => openVideo(v.id)} className="card-lift group w-full overflow-hidden rounded-[1.6rem] bg-[var(--surface)] text-left ring-line">
                <div className="img-zoom relative">
                  <ImgBox src={v.thumbnail || ytThumb(v.url)} alt={v.title} className="aspect-video w-full" />
                  <span className="absolute inset-0 bg-black/10 transition group-hover:bg-black/25" />
                  <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/25 text-white backdrop-blur transition duration-300 group-hover:scale-110 group-hover:bg-[var(--primary)]">
                    <Play size={20} className="ml-0.5 fill-current" />
                  </span>
                </div>
                <div className="p-5">
                  <Chip>{v.category}</Chip>
                  <h3 className="mt-2 line-clamp-2 font-display text-lg font-bold leading-snug">{v.title}</h3>
                  <div className="mt-2 flex items-center justify-between text-xs tx-faint">
                    <span>{fmtDate(v.date)}</span>
                    <span className="flex items-center gap-1"><Eye size={12} /> {v.views}</span>
                  </div>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      )}

      <Modal open={!!open} onClose={() => setOpenId(undefined)} wide>
        {open && (
          <div className={cx("relative")}>
            <CloseBtn onClick={() => setOpenId(undefined)} />
            <div className="overflow-hidden rounded-2xl bg-black">
              {youtubeId(open.url) ? (
                <iframe
                  className="aspect-video w-full"
                  src={`https://www.youtube.com/embed/${youtubeId(open.url)}?autoplay=1&rel=0`}
                  title={open.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <video className="aspect-video w-full" src={open.url} controls autoPlay />
              )}
            </div>
            <div className="mt-5">
              <Chip>{open.category}</Chip>
              <h3 className="mt-2 font-display text-xl font-bold sm:text-2xl">{open.title}</h3>
              <div className="mt-1.5 flex items-center gap-4 text-xs tx-faint">
                <span>{fmtDate(open.date)}</span>
                <span className="flex items-center gap-1"><Eye size={12} /> {open.views} views</span>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </main>
  );
}
