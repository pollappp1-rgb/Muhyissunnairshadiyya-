import {
  ArrowRight, ArrowUpRight, BookOpen, CalendarDays, Flag, Heart, Images, MapPin, MessagesSquare,
  Newspaper, Play, Sparkles, Trophy,
} from "lucide-react";
import { CountUp, Eyebrow, Reveal, SplitText } from "../components/anim";
import { Avatar, Btn, Chip, IconByName, ImgBox } from "../components/ui";
import { useSite } from "../store";
import { cx, fmtDate, ytThumb } from "../utils";
import type { PageKey } from "../types";

export default function HomePage() {
  const { data } = useSite();
  const sections = data.homeLayout.filter((s) => s.visible);
  return (
    <main>
      {sections.map((s) => (
        <SectionRenderer key={s.id} id={s.id} />
      ))}
    </main>
  );
}

function SectionRenderer({ id }: { id: string }) {
  switch (id) {
    case "hero": return <HeroSec />;
    case "explore": return <ExploreSec />;
    case "stats": return <StatsSec />;
    case "featured": return <FeaturedSec />;
    case "works": return <WorksSec />;
    case "magazines": return <MagsSec />;
    case "gallery": return <GallerySec />;
    case "videos": return <VideosSec />;
    case "events": return <EventsSec />;
    case "awards": return <AwardsSec />;
    case "committee": return <CommitteeSec />;
    case "community": return <CommunitySec />;
    default: return null;
  }
}

function PageWrap({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <section className={cx("mx-auto max-w-7xl px-4 sm:px-6", className)}>{children}</section>;
}

function SectionHead({ eyebrow, title, target }: { eyebrow: string; title: string; target?: PageKey }) {
  const { nav } = useSite();
  return (
    <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
      <div>
        <Eyebrow>{eyebrow}</Eyebrow>
        <Reveal delay={80}>
          <h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl md:text-[2.6rem]">{title}</h2>
        </Reveal>
      </div>
      {target && (
        <Reveal delay={140}>
          <Btn variant="outline" size="sm" onClick={() => nav(target)}>
            View all <ArrowUpRight size={14} />
          </Btn>
        </Reveal>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
function HeroSec() {
  const { data, nav } = useSite();
  const s = data.settings;
  const mag = data.magazines.find((m) => m.visible);
  const members = data.members.filter((m) => m.visible).slice(0, 4);
  const heroSizes: Record<string, { t: string; a: string }> = {
    compact: { t: "clamp(2.4rem, 6.5vw, 3.8rem)", a: "clamp(1.3rem, 4.5vw, 2.3rem)" },
    classic: { t: "clamp(3rem, 9vw, 5.2rem)", a: "clamp(1.7rem, 6vw, 3rem)" },
    grand: { t: "clamp(3.4rem, 11vw, 6.4rem)", a: "clamp(1.9rem, 7vw, 3.6rem)" },
    massive: { t: "clamp(3.8rem, 13vw, 7.8rem)", a: "clamp(2.1rem, 8vw, 4.2rem)" },
  };
  const hz = heroSizes[s.heroTitleSize] || heroSizes.grand;
  const heroFont = s.heroTitleFont === "sans" ? "font-extrabold" : s.heroTitleFont === "ar" ? "font-ar" : "font-display";
  const showVisual = s.showHeroImage && !!s.heroImage;

  return (
    <section className="relative overflow-hidden">
      <div className="grain pointer-events-none absolute inset-0" />
      <div
        className="pointer-events-none absolute -left-32 top-0 h-[480px] w-[480px] rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(circle, color-mix(in srgb, var(--primary) 26%, transparent), transparent 70%)" }}
      />
      <div
        className="pointer-events-none absolute -right-24 bottom-0 h-[420px] w-[420px] rounded-full opacity-50 blur-3xl"
        style={{ background: "radial-gradient(circle, color-mix(in srgb, var(--accent) 30%, transparent), transparent 70%)" }}
      />
      <PageWrap className={cx("relative grid items-center gap-12 pb-20 pt-14 lg:pt-20", showVisual ? "lg:grid-cols-[1.15fr_1fr]" : "lg:max-w-4xl")}>
        <div>
          <Reveal>
            <Chip className="mb-6">
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--primary)]"><span className="pulse-dot tx-primary" /></span>
              <Sparkles size={12} className="tx-primary" />
              {s.heroBadge}
            </Chip>
          </Reveal>
          <h1
            className={cx(heroFont, "font-black leading-[0.95] tracking-tight")}
            style={{ fontSize: hz.t, color: s.heroTitleColor || "var(--ink)" }}
          >
            <SplitText text={s.heroTitle} charDelay={40} startDelay={150} />
          </h1>
          <div className="mt-2 flex items-center gap-4">
            <span className="h-[3px] w-10 rounded-full bg-accent sm:w-16" />
            <span
              className="font-display font-semibold italic tracking-[0.06em]"
              style={{ fontSize: hz.a, color: s.heroAccentColor || "var(--accent)" }}
            >
              <SplitText text={s.heroAccent} charDelay={50} startDelay={650} />
            </span>
          </div>
          <Reveal delay={950}>
            <p className="mt-6 max-w-xl text-base leading-relaxed tx-soft sm:text-lg">{s.heroSubtitle}</p>
          </Reveal>
          <Reveal delay={1100}>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Btn size="lg" onClick={() => nav("works")}>
                <BookOpen size={17} /> Explore Publications
              </Btn>
              <Btn size="lg" variant="outline" onClick={() => nav("magazines")}>
                <Newspaper size={17} /> Digital Magazine
              </Btn>
            </div>
          </Reveal>
          <Reveal delay={1250}>
            <div className="mt-10 flex items-center gap-4">
              <div className="flex -space-x-3">
                {members.map((m) => (
                  <Avatar key={m.id} name={m.name} photo={m.photo} sizeClass="h-10 w-10" textClass="text-xs" />
                ))}
              </div>
              <button onClick={() => nav("committee")} className="text-left text-sm font-semibold tx-soft transition hover:tx-primary">
                Led by the student committee
                <span className="mt-0.5 flex items-center gap-1 text-xs tx-faint">Meet the team <ArrowRight size={12} /></span>
              </button>
            </div>
          </Reveal>
        </div>

        {showVisual && (
        <Reveal delay={400} y={40} className="relative">
          <div className="relative mx-auto max-w-md">
            <div className="arch img-zoom relative overflow-hidden border-[6px] border-[var(--surface)] shadow-2xl">
              <img src={s.heroImage} alt="Campus" className="aspect-[4/5] w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent" />
            </div>
            {mag && (
              <button
                onClick={() => nav("magazines", mag.id)}
                className="floaty absolute -left-6 bottom-10 flex w-44 items-center gap-3 rounded-2xl bg-[var(--surface)] p-2.5 text-left shadow-xl ring-1 ring-black/5 sm:-left-12"
              >
                <ImgBox src={mag.cover} alt={mag.title} className="h-16 w-12 shrink-0 rounded-lg" />
                <span>
                  <span className="block text-[10px] font-bold uppercase tracking-[0.2em] tx-accent">New Issue</span>
                  <span className="mt-0.5 block font-display text-sm font-bold leading-tight">{mag.title} · {mag.issue.split("·")[0]}</span>
                </span>
              </button>
            )}
            <div className="floaty-slow absolute -right-3 -top-4 rounded-2xl bg-ink px-4 py-3 text-[var(--bg)] shadow-xl sm:-right-8">
              <div className="font-display text-2xl font-bold">
                <CountUp to={data.publications.filter((p) => p.visible).length} suffix="+" />
              </div>
              <div className="text-[10px] font-bold uppercase tracking-[0.18em] opacity-70">Student Works</div>
            </div>
          </div>
        </Reveal>
        )}
      </PageWrap>
    </section>
  );
}

/* ------------------------------------------------------------------ */
function ExploreSec() {
  const { data, nav } = useSite();
  const buttons = data.homeButtons.filter((b) => b.visible);
  if (buttons.length === 0) return null;
  return (
    <PageWrap className="pb-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
        {buttons.map((b, i) => (
          <Reveal key={b.id} delay={i * 80}>
            <button
              onClick={() => nav(b.target as PageKey)}
              className="card-lift group flex w-full items-center gap-3 rounded-2xl bg-[var(--surface)] p-4 text-left ring-line sm:p-5"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[color-mix(in_srgb,var(--primary)_10%,transparent)] tx-primary transition-transform duration-300 group-hover:scale-110">
                <IconByName name={b.icon} size={19} />
              </span>
              <span className="min-w-0">
                <span className="block truncate text-sm font-bold">{b.label}</span>
                <span className="mt-0.5 flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wider tx-faint">
                  Open <ArrowUpRight size={11} />
                </span>
              </span>
            </button>
          </Reveal>
        ))}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function StatsSec() {
  const { data } = useSite();
  const stats = [
    { icon: BookOpen, label: "Publications", value: data.publications.filter((p) => p.visible).length },
    { icon: Newspaper, label: "Magazine Issues", value: data.magazines.filter((m) => m.visible).length },
    { icon: Images, label: "Photos Archived", value: data.albums.filter((a) => a.visible).reduce((n, a) => n + a.images.length, 0) },
    { icon: CalendarDays, label: "Programs", value: data.events.filter((e) => e.visible).length },
  ];
  return (
    <PageWrap className="py-14">
      <Reveal>
        <div className="grid grid-cols-2 divide-y overflow-hidden rounded-[2rem] bg-ink text-[var(--bg)] sm:grid-cols-4 sm:divide-x sm:divide-y-0 divide-white/10">
          {stats.map((s) => (
            <div key={s.label} className="group p-6 sm:p-8">
              <s.icon size={20} className="tx-accent transition-transform duration-500 group-hover:-rotate-12 group-hover:scale-110" />
              <div className="mt-4 font-display text-4xl font-bold sm:text-5xl">
                <CountUp to={s.value} />
              </div>
              <div className="mt-1 text-[11px] font-bold uppercase tracking-[0.22em] opacity-60">{s.label}</div>
            </div>
          ))}
        </div>
      </Reveal>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function FeaturedSec() {
  const { data, nav, liked } = useSite();
  const featured = data.publications.filter((p) => p.visible && p.featured);
  const fallback = data.publications.filter((p) => p.visible).slice(0, 3);
  const list = (featured.length > 0 ? featured : fallback).slice(0, 3);
  if (list.length === 0) return null;
  const [main, ...rest] = list;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="Editor's Choice" title="Featured this week" target="works" />
      <div className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
        <Reveal>
          <button
            onClick={() => nav("works", main.id)}
            className={cx("card-lift group grid w-full overflow-hidden rounded-[2rem] bg-[var(--surface)] text-left ring-line", main.thumbnail && "sm:grid-cols-2")}
          >
            {main.thumbnail && (
              <ImgBox src={main.thumbnail} alt={main.title} className="h-56 w-full sm:h-full sm:min-h-[320px]" imgClassName="group-hover:scale-105 transition-transform duration-700" />
            )}
            <span className="flex flex-col justify-center p-7 sm:p-8">
              <span className="flex flex-wrap items-center gap-2">
                <Chip color="#c9a24b"><Sparkles size={11} /> Featured</Chip>
                <Chip>{main.category}</Chip>
              </span>
              <span className="mt-4 font-display text-2xl font-bold leading-snug sm:text-3xl">{main.title}</span>
              <span className="mt-3 line-clamp-3 text-sm leading-relaxed tx-soft">{main.excerpt}</span>
              <span className="mt-5 flex items-center justify-between text-sm">
                <span className="font-semibold">{main.author}</span>
                <span className="flex items-center gap-1.5 tx-faint">
                  <Heart size={14} className={liked(main.id) ? "fill-red-500 text-red-500" : ""} /> {main.likes}
                </span>
              </span>
              <span className="mt-5 inline-flex items-center gap-2 text-sm font-bold tx-primary">
                Read now <ArrowRight size={15} className="transition-transform duration-300 group-hover:translate-x-1.5" />
              </span>
            </span>
          </button>
        </Reveal>
        <div className="grid content-start gap-5">
          {rest.map((p, i) => (
            <Reveal key={p.id} delay={100 + i * 100}>
              <button
                onClick={() => nav("works", p.id)}
                className="card-lift group flex w-full items-center gap-4 rounded-[1.6rem] bg-[var(--surface)] p-3.5 text-left ring-line"
              >
                {p.thumbnail && <ImgBox src={p.thumbnail} alt={p.title} className="h-24 w-24 shrink-0 rounded-2xl sm:h-28 sm:w-28" />}
                <span className="min-w-0">
                  <Chip>{p.category}</Chip>
                  <span className="mt-1.5 line-clamp-2 block font-display text-lg font-bold leading-snug">{p.title}</span>
                  <span className="mt-1 block text-xs tx-faint">{p.author} · {fmtDate(p.date)}</span>
                </span>
              </button>
            </Reveal>
          ))}
        </div>
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function WorksSec() {
  const { data, nav, liked } = useSite();
  const pubs = data.publications.filter((p) => p.visible).slice(0, 6);
  if (pubs.length === 0) return null;
  const catColor = (n: string) => data.categories.find((c) => c.name === n)?.color;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="Fresh Ink" title="Latest student publications" target="works" />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {pubs.map((p, i) => (
          <Reveal key={p.id} delay={(i % 3) * 90}>
            <button onClick={() => nav("works", p.id)} className="card-lift group w-full overflow-hidden rounded-[1.6rem] bg-[var(--surface)] text-left ring-line">
              {p.thumbnail && (
                <div className="img-zoom relative">
                  <ImgBox src={p.thumbnail} alt={p.title} className="aspect-[16/10] w-full" />
                  <span className="absolute left-3 top-3"><Chip color={catColor(p.category)}>{p.category}</Chip></span>
                </div>
              )}
              <span className="block p-5">
                {!p.thumbnail && <span className="mb-2 inline-block"><Chip color={catColor(p.category)}>{p.category}</Chip></span>}
                <span className="line-clamp-2 font-display text-lg font-bold leading-snug">{p.title}</span>
                <span className="mt-2 line-clamp-2 text-sm tx-soft">{p.excerpt}</span>
                <span className="mt-4 flex items-center justify-between text-xs">
                  <span className="font-semibold">{p.author}</span>
                  <span className="flex items-center gap-1.5 tx-faint">
                    <Heart size={13} className={liked(p.id) ? "fill-red-500 text-red-500" : ""} /> {p.likes}
                  </span>
                </span>
              </span>
            </button>
          </Reveal>
        ))}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function MagsSec() {
  const { data, nav } = useSite();
  const mags = data.magazines.filter((m) => m.visible);
  if (mags.length === 0) return null;
  return (
    <section className="my-14 bg-ink py-16 text-[var(--bg)]">
      <PageWrap>
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="h-px w-8 bg-accent" />
              <span className="text-[11px] font-semibold uppercase tracking-[0.28em] tx-accent">The Digital Magazine</span>
            </div>
            <Reveal delay={80}><h2 className="mt-2 font-display text-3xl font-bold tracking-tight sm:text-4xl">Issues of the association</h2></Reveal>
          </div>
          <Btn variant="accent" size="sm" onClick={() => nav("magazines")}>Browse archive <ArrowUpRight size={14} /></Btn>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-4 no-scrollbar">
          {mags.map((m, i) => (
            <Reveal key={m.id} delay={i * 100} className="shrink-0">
              <button onClick={() => nav("magazines", m.id)} className="card-lift group block w-44 text-left sm:w-52">
                <div className="img-zoom overflow-hidden rounded-2xl border-4 border-white/10 shadow-2xl">
                  <ImgBox src={m.cover} alt={m.title} className="aspect-[3/4] w-full" />
                </div>
                <div className="mt-3 font-display text-lg font-bold">{m.title}</div>
                <div className="text-xs opacity-60">{m.issue}</div>
              </button>
            </Reveal>
          ))}
        </div>
      </PageWrap>
    </section>
  );
}

/* ------------------------------------------------------------------ */
function GallerySec() {
  const { data, nav } = useSite();
  const albums = data.albums.filter((a) => a.visible).slice(0, 4);
  if (albums.length === 0) return null;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="Moments" title="From the photo diary" target="gallery" />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {albums.map((a, i) => (
          <Reveal key={a.id} delay={(i % 4) * 80}>
            <button onClick={() => nav("gallery", a.id)} className="card-lift group img-zoom relative w-full overflow-hidden rounded-[1.6rem] text-left">
              <ImgBox src={a.cover} alt={a.title} className="aspect-[4/5] w-full" />
              <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
              <span className="absolute inset-x-0 bottom-0 p-5 text-white">
                <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">
                  <Images size={12} /> {a.images.length} photos
                </span>
                <span className="mt-1 block font-display text-lg font-bold leading-snug">{a.title}</span>
              </span>
            </button>
          </Reveal>
        ))}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function VideosSec() {
  const { data, nav } = useSite();
  const vids = data.videos.filter((v) => v.visible).slice(0, 3);
  if (vids.length === 0) return null;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="Watch" title="Video hub" target="videos" />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {vids.map((v, i) => (
          <Reveal key={v.id} delay={(i % 3) * 90}>
            <button onClick={() => nav("videos", v.id)} className="card-lift group img-zoom relative w-full overflow-hidden rounded-[1.6rem] text-left">
              <ImgBox src={v.thumbnail || ytThumb(v.url)} alt={v.title} className="aspect-video w-full" />
              <span className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
              <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur transition duration-300 group-hover:scale-110 group-hover:bg-[var(--primary)]">
                <Play size={20} className="ml-0.5 fill-current" />
              </span>
              <span className="absolute inset-x-0 bottom-0 p-5 text-white">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">{v.category}</span>
                <span className="mt-1 line-clamp-2 block font-display font-bold leading-snug">{v.title}</span>
              </span>
            </button>
          </Reveal>
        ))}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function EventsSec() {
  const { data, nav } = useSite();
  const events = data.events.filter((e) => e.visible).slice(0, 3);
  if (events.length === 0) return null;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="Mark the date" title="Upcoming programs" target="events" />
      <div className="grid gap-4">
        {events.map((e, i) => {
          const d = new Date(e.date);
          return (
            <Reveal key={e.id} delay={i * 90}>
              <button
                onClick={() => nav("events")}
                className="card-lift flex w-full items-center gap-5 rounded-[1.6rem] bg-[var(--surface)] p-4 text-left ring-line sm:p-5"
              >
                <span className="flex h-20 w-20 shrink-0 flex-col items-center justify-center rounded-2xl bg-primary tx-on sm:h-24 sm:w-24">
                  <span className="font-display text-3xl font-bold sm:text-4xl">{d.getDate()}</span>
                  <span className="text-[10px] font-bold uppercase tracking-[0.24em] opacity-80">
                    {d.toLocaleDateString("en-IN", { month: "short" })}
                  </span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="line-clamp-1 font-display text-lg font-bold sm:text-xl">{e.title}</span>
                  <span className="mt-1 line-clamp-1 flex items-center gap-2 text-sm tx-soft">
                    <MapPin size={13} /> {e.venue} {e.time && `· ${e.time}`}
                  </span>
                  <span className="mt-1.5 line-clamp-1 text-sm tx-faint">{e.description}</span>
                </span>
                <ArrowUpRight size={18} className="hidden shrink-0 tx-faint sm:block" />
              </button>
            </Reveal>
          );
        })}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function AwardsSec() {
  const { data } = useSite();
  const awards = data.awards.filter((a) => a.visible && a.kind === "achievement").slice(0, 2);
  const results = data.awards.filter((a) => a.visible && a.kind === "result").slice(0, 2);
  if (awards.length + results.length === 0) return null;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="Hall of Fame" title="Achievements & results" target="awards" />
      <div className="grid gap-5 lg:grid-cols-2">
        {awards.map((a, i) => (
          <Reveal key={a.id} delay={i * 90}>
            <div className="card-lift flex h-full items-center gap-4 rounded-[1.6rem] bg-[var(--surface)] p-5 ring-line">
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[color-mix(in_srgb,var(--accent)_18%,transparent)] tx-accent">
                <Trophy size={22} />
              </span>
              <span className="min-w-0">
                <span className="line-clamp-1 font-display text-lg font-bold">{a.title}</span>
                <span className="mt-0.5 block text-sm font-semibold tx-primary">{a.name}</span>
                <span className="mt-0.5 line-clamp-1 text-xs tx-faint">{a.detail} · {a.year}</span>
              </span>
            </div>
          </Reveal>
        ))}
        {results.map((r, i) => (
          <Reveal key={r.id} delay={i * 90}>
            <div className="card-lift flex h-full items-center gap-4 rounded-[1.6rem] bg-[var(--surface)] p-5 ring-line">
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[color-mix(in_srgb,var(--primary)_12%,transparent)] tx-primary">
                <Newspaper size={20} />
              </span>
              <span className="min-w-0">
                <span className="line-clamp-1 text-[11px] font-bold uppercase tracking-[0.2em] tx-faint">Result · {r.year}</span>
                <span className="line-clamp-1 font-display text-lg font-bold">{r.title}</span>
                <span className="mt-0.5 line-clamp-1 text-xs tx-soft">{r.name}</span>
              </span>
            </div>
          </Reveal>
        ))}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function CommitteeSec() {
  const { data, nav } = useSite();
  const members = data.members.filter((m) => m.visible).slice(0, 4);
  if (members.length === 0) return null;
  return (
    <PageWrap className="py-10">
      <SectionHead eyebrow="The Team" title="Association committee" target="committee" />
      <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
        {members.map((m, i) => (
          <Reveal key={m.id} delay={(i % 4) * 80}>
            <button onClick={() => nav("committee")} className="card-lift w-full rounded-[1.6rem] bg-[var(--surface)] p-6 text-center ring-line">
              <Avatar name={m.name} photo={m.photo} sizeClass="mx-auto h-20 w-20" textClass="text-xl" />
              <div className="mt-4 font-display text-lg font-bold leading-tight">{m.name}</div>
              <div className="mt-1.5"><Chip>{m.role}</Chip></div>
            </button>
          </Reveal>
        ))}
      </div>
    </PageWrap>
  );
}

/* ------------------------------------------------------------------ */
function CommunitySec() {
  const { nav } = useSite();
  return (
    <PageWrap className="py-10">
      <div className="grid gap-5 md:grid-cols-2">
        <Reveal>
          <button onClick={() => nav("forums")} className="card-lift group relative w-full overflow-hidden rounded-[2rem] bg-primary p-8 text-left tx-on sm:p-10">
            <MessagesSquare size={120} className="absolute -right-6 -top-6 opacity-15 transition-transform duration-500 group-hover:rotate-6" />
            <span className="text-[11px] font-bold uppercase tracking-[0.28em] opacity-80">Student Forums</span>
            <span className="mt-2 block font-display text-2xl font-bold sm:text-3xl">Ask, discuss, get answers</span>
            <span className="mt-3 block max-w-sm text-sm opacity-85">Open a topic and the association team replies right here — live.</span>
            <span className="mt-6 inline-flex items-center gap-2 rounded-full bg-white/15 px-5 py-2.5 text-sm font-bold backdrop-blur">
              Open forums <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" />
            </span>
          </button>
        </Reveal>
        <Reveal delay={120}>
          <button onClick={() => nav("report")} className="card-lift group relative w-full overflow-hidden rounded-[2rem] bg-ink p-8 text-left text-[var(--bg)] sm:p-10">
            <Flag size={120} className="absolute -right-6 -top-6 opacity-15 transition-transform duration-500 group-hover:-rotate-6" />
            <span className="text-[11px] font-bold uppercase tracking-[0.28em] tx-accent">Voice It</span>
            <span className="mt-2 block font-display text-2xl font-bold sm:text-3xl">Report or suggest</span>
            <span className="mt-3 block max-w-sm text-sm opacity-85">Complaints and suggestions reach the admin panel instantly — with your name.</span>
            <span className="mt-6 inline-flex items-center gap-2 rounded-full bg-[var(--accent)] px-5 py-2.5 text-sm font-bold text-[var(--ink)]">
              Send a report <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" />
            </span>
          </button>
        </Reveal>
      </div>
    </PageWrap>
  );
}
