import { useState } from "react";
import { Bell, CalendarDays, Clock, ExternalLink, MapPin, Medal, Megaphone, ScrollText, Trophy } from "lucide-react";
import { Eyebrow, Reveal, SplitText } from "../components/anim";
import { Chip, EmptyState, ImgBox } from "../components/ui";
import { useSite } from "../store";
import { cx, fmtDate } from "../utils";

function Head({ eyebrow, title, sub }: { eyebrow: string; title: string; sub: string }) {
  return (
    <>
      <Eyebrow>{eyebrow}</Eyebrow>
      <Reveal delay={80}>
        <h1 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
          <SplitText text={title} charDelay={30} startDelay={150} />
        </h1>
      </Reveal>
      <Reveal delay={160}>
        <p className="mt-3 max-w-2xl tx-soft">{sub}</p>
      </Reveal>
    </>
  );
}

/* ================================================================== */
export function EventsPage() {
  const { data } = useSite();
  const events = data.events
    .filter((e) => e.visible)
    .slice()
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return (
    <main className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
      <Head eyebrow="Programs" title="Events calendar" sub="Meetings, competitions, launches and celebrations — everything the association is planning." />
      {events.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<CalendarDays size={24} />} title="No events scheduled" sub="New programs will be announced soon." /></div>
      ) : (
        <div className="mt-10 grid gap-4">
          {events.map((e, i) => {
            const d = new Date(e.date);
            const past = d < today;
            return (
              <Reveal key={e.id} delay={(i % 4) * 70}>
                <article className={cx("card-lift flex gap-5 rounded-[1.6rem] bg-[var(--surface)] p-5 ring-line sm:p-6", past && "opacity-70")}>
                  <div
                    className={cx(
                      "flex h-24 w-24 shrink-0 flex-col items-center justify-center rounded-2xl",
                      past ? "soft-panel tx-faint" : "bg-primary tx-on"
                    )}
                  >
                    <span className="font-display text-4xl font-bold">{d.getDate()}</span>
                    <span className="text-[10px] font-bold uppercase tracking-[0.24em] opacity-80">
                      {d.toLocaleDateString("en-IN", { month: "short" })} '{String(d.getFullYear()).slice(2)}
                    </span>
                    {past
                      ? <span className="mt-1 rounded-full bg-black/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest">Done</span>
                      : <span className="mt-1 rounded-full bg-white/20 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest">Soon</span>}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-display text-xl font-bold leading-snug">{e.title}</h3>
                    <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-sm tx-soft">
                      <span className="flex items-center gap-1.5"><MapPin size={13} /> {e.venue}</span>
                      {e.time && <span className="flex items-center gap-1.5"><Clock size={13} /> {e.time}</span>}
                    </div>
                    {e.description && <p className="mt-2 line-clamp-2 text-sm tx-faint">{e.description}</p>}
                  </div>
                  {e.poster && (
                    <ImgBox src={e.poster} alt={e.title} className="hidden h-24 w-24 shrink-0 rounded-2xl sm:block" />
                  )}
                </article>
              </Reveal>
            );
          })}
        </div>
      )}
    </main>
  );
}

/* ================================================================== */
export function NoticesPage() {
  const { data } = useSite();
  const notices = data.notices
    .filter((n) => n.visible)
    .slice()
    .sort((a, b) => Number(b.important) - Number(a.important) || new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <Head eyebrow="Notice Board" title="Notifications" sub="Official announcements from the association — important ones stay pinned to the top." />
      {notices.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Bell size={24} />} title="No notices right now" sub="Check back after the next association meeting." /></div>
      ) : (
        <div className="mt-10 grid gap-4">
          {notices.map((n, i) => (
            <Reveal key={n.id} delay={(i % 5) * 60}>
              <article
                className={cx(
                  "card-lift flex items-start gap-4 rounded-[1.6rem] bg-[var(--surface)] p-5 ring-line",
                  n.important && "border-l-4 border-[var(--accent)]"
                )}
              >
                <span
                  className={cx(
                    "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl",
                    n.important ? "bg-[color-mix(in_srgb,var(--accent)_20%,transparent)] tx-accent" : "soft-panel tx-faint"
                  )}
                >
                  <Megaphone size={18} />
                </span>
                <div className="min-w-0 flex-1">
                  {n.important && <Chip color="#c9a24b" className="mb-2">Important</Chip>}
                  <p className="text-[15px] font-medium leading-relaxed">{n.text}</p>
                  <div className="mt-2 flex items-center gap-4 text-xs tx-faint">
                    <span>{fmtDate(n.date)}</span>
                    {n.link && (
                      <a href={n.link} target="_blank" rel="noreferrer" className="flex items-center gap-1 font-bold tx-primary hover:underline">
                        Open attachment <ExternalLink size={11} />
                      </a>
                    )}
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}

/* ================================================================== */
const MEDALS = ["#c9a24b", "#9ca3af", "#b45309"];

export function AwardsPage() {
  const { data } = useSite();
  const [tab, setTab] = useState<"achievement" | "result">("achievement");
  const items = data.awards.filter((a) => a.visible && a.kind === tab);

  return (
    <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
      <Head eyebrow="Hall of Fame" title="Achievements & Results" sub="Prizes our students bring home — and official results of association programs." />

      <Reveal delay={200}>
        <div className="mt-8 inline-flex rounded-full border line bg-[var(--surface)] p-1.5">
          {(["achievement", "result"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cx(
                "flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold uppercase tracking-widest transition",
                tab === t ? "bg-primary tx-on shadow" : "tx-soft hover:tx"
              )}
            >
              {t === "achievement" ? <Trophy size={14} /> : <ScrollText size={14} />}
              {t === "achievement" ? "Achievements" : "Results"}
            </button>
          ))}
        </div>
      </Reveal>

      {items.length === 0 ? (
        <div className="mt-12"><EmptyState icon={<Trophy size={24} />} title="Nothing here yet" sub="Entries will be added by the admin." /></div>
      ) : (
        <div key={tab} className="fade-in mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((a, i) => (
            <Reveal key={a.id} delay={(i % 3) * 80}>
              <article className="card-lift h-full overflow-hidden rounded-[1.6rem] bg-[var(--surface)] ring-line">
                {a.image && <ImgBox src={a.image} alt={a.title} className="aspect-[16/9] w-full" />}
                <div className="p-6">
                  <div className="flex items-start justify-between gap-3">
                    <span
                      className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl"
                      style={{ background: `color-mix(in srgb, ${MEDALS[i % 3]} 18%, transparent)`, color: MEDALS[i % 3] }}
                    >
                      <Medal size={22} />
                    </span>
                    <Chip>{a.year}</Chip>
                  </div>
                  <h3 className="mt-4 font-display text-xl font-bold leading-snug">{a.title}</h3>
                  <p className="mt-1.5 text-sm font-semibold tx-primary">{a.name}</p>
                  {a.detail && <p className="mt-1.5 text-sm leading-relaxed tx-faint">{a.detail}</p>}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      )}
    </main>
  );
}
