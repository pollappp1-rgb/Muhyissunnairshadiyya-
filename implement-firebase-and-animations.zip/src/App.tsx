import { useEffect } from "react";
import AdminApp from "./admin/AdminApp";
import { BottomTab, Footer, Header, PopupAlert, Toasts } from "./components/Chrome";
import { StoreProvider, useSite } from "./store";
import HomePage from "./pages/Home";
import WorksPage from "./pages/Works";
import { GalleryPage, MagazinesPage, VideosPage } from "./pages/Media";
import { AwardsPage, EventsPage, NoticesPage } from "./pages/Board";
import { AboutPage, CommitteePage, ForumsPage, ReportPage } from "./pages/Community";

function Shell() {
  const { route, data } = useSite();
  const t = data.settings.theme;

  useEffect(() => {
    const root = document.documentElement;
    const vars: Record<string, string> = {
      "--bg": t.bg,
      "--surface": t.surface,
      "--ink": t.ink,
      "--primary": t.primary,
      "--on-primary": t.onPrimary,
      "--accent": t.accent,
      "--ticker-bg": t.tickerBg,
      "--ticker-text": t.tickerText,
    };
    for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);
  }, [t]);

  if (route.page === "admin") {
    return (
      <>
        <AdminApp />
        <Toasts />
      </>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      {route.page === "home" && <HomePage />}
      {route.page === "works" && <WorksPage key={route.id || "all"} />}
      {route.page === "magazines" && <MagazinesPage key={route.id || "all"} />}
      {route.page === "gallery" && <GalleryPage key={route.id || "all"} />}
      {route.page === "videos" && <VideosPage key={route.id || "all"} />}
      {route.page === "events" && <EventsPage />}
      {route.page === "notices" && <NoticesPage />}
      {route.page === "awards" && <AwardsPage />}
      {route.page === "committee" && <CommitteePage />}
      {route.page === "forums" && <ForumsPage />}
      {route.page === "report" && <ReportPage />}
      {route.page === "about" && <AboutPage />}
      <Footer />
      <BottomTab />
      <PopupAlert />
      <Toasts />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
