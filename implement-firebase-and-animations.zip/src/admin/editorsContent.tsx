import { useRef, useState } from "react";
import { Heart, Images, Pencil, Plus, Star, Trash2, X } from "lucide-react";
import { Btn, Chip, ConfirmDialog, Field, FileOrLink, ImgBox, Modal, SelectInput, TextArea, TextInput, Toggle } from "../components/ui";
import { useSite } from "../store";
import { cx, fmtDate, processImageFile, todayISO, uid, ytThumb } from "../utils";
import type { Album, Category, EventItem, Magazine, Publication, VideoItem } from "../types";
import { ACT, AdminHead, MoveBtns, Row, VisToggle, move, useCrud } from "./shared";

function dateInput(iso: string): string {
  return iso ? iso.slice(0, 10) : "";
}
function fromDateInput(v: string, fallback: string): string {
  return v ? new Date(v + "T09:00:00").toISOString() : fallback;
}

function EditActions({ onEdit, onDel, vis, onVis }: { onEdit: () => void; onDel: () => void; vis: boolean; onVis: (v: boolean) => void }) {
  return (
    <span className="flex shrink-0 items-center gap-0.5">
      <VisToggle v={vis} onChange={onVis} />
      <button type="button" className={ACT} onClick={onEdit} title="Edit"><Pencil size={15} /></button>
      <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={onDel} title="Delete"><Trash2 size={15} /></button>
    </span>
  );
}

/* ================================================================== */
export function PublicationsEditor() {
  const { items, save } = useCrud("publications");
  const { data, toast } = useSite();
  const [editing, setEditing] = useState<Publication | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const blank: Publication = {
    id: "", title: "", author: "", category: data.categories[0]?.name || "Article",
    excerpt: "", content: "", thumbnail: "", date: todayISO(), likes: 0, featured: false, visible: true,
  };

  const commit = () => {
    if (!editing) return;
    if (!editing.title.trim() || !editing.author.trim()) {
      toast("Title and author are required.", "error");
      return;
    }
    if (editing.id) save(items.map((p) => (p.id === editing.id ? editing : p)), "Publication updated — live on the site.");
    else save([{ ...editing, id: uid() }, ...items], "Publication added — live on the site.");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Publications"
        sub="Poems, stories, essays, articles & speeches with thumbnails and likes."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> New work</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((p) => (
          <Row key={p.id}>
            <ImgBox src={p.thumbnail} alt="" className="h-14 w-14 shrink-0 rounded-xl" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{p.title}</div>
              <div className="mt-0.5 truncate text-xs tx-faint">
                {p.category} · {p.author} · <Heart size={10} className="inline" /> {p.likes} · {fmtDate(p.date)}
              </div>
            </div>
            <button
              type="button"
              className={ACT}
              title="Toggle featured"
              onClick={() => save(items.map((x) => (x.id === p.id ? { ...x, featured: !x.featured } : x)), p.featured ? "Removed from featured" : "Marked as featured")}
            >
              <Star size={15} className={p.featured ? "fill-amber-400 text-amber-400" : "opacity-40"} />
            </button>
            <EditActions
              vis={p.visible}
              onVis={(v) => save(items.map((x) => (x.id === p.id ? { ...x, visible: v } : x)))}
              onEdit={() => setEditing(p)}
              onDel={() => setDelId(p.id)}
            />
          </Row>
        ))}
        {items.length === 0 && <p className="py-10 text-center text-sm tx-faint">No publications yet — add the first one.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this publication?"
        message="This removes it from the site for everyone. This cannot be undone."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((p) => p.id !== delId), "Publication deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)} wide>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit publication" : "New publication"}</h3>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Field label="Title"><TextInput value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} /></Field>
              </div>
              <Field label="Author"><TextInput value={editing.author} onChange={(e) => setEditing({ ...editing, author: e.target.value })} /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Category">
                  <SelectInput value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })}>
                    {[...new Set([...data.categories.map((c) => c.name), editing.category])].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </SelectInput>
                </Field>
                <Field label="Date">
                  <TextInput type="date" value={dateInput(editing.date)} onChange={(e) => setEditing({ ...editing, date: fromDateInput(e.target.value, editing.date) })} />
                </Field>
              </div>
              <div className="sm:col-span-2">
                <Field label="Excerpt" hint="shown on cards">
                  <TextArea value={editing.excerpt} onChange={(e) => setEditing({ ...editing, excerpt: e.target.value })} className="min-h-[70px]" />
                </Field>
              </div>
              <div className="sm:col-span-2">
                <Field label="Full content" hint="blank line = new paragraph">
                  <TextArea value={editing.content} onChange={(e) => setEditing({ ...editing, content: e.target.value })} className="min-h-[180px]" />
                </Field>
              </div>
              <div className="sm:col-span-2">
                <FileOrLink label="Thumbnail" kind="image" value={editing.thumbnail} onChange={(v) => setEditing({ ...editing, thumbnail: v })} hint="optional — works publish fine without one" />
              </div>
              <Toggle checked={editing.featured} onChange={(v) => setEditing({ ...editing, featured: v })} label="Featured on homepage" />
              <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible on site" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save & publish</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function CategoriesEditor() {
  const { items, save } = useCrud("categories");
  const { data } = useSite();
  const [editing, setEditing] = useState<Category | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const commit = () => {
    if (!editing || !editing.name.trim()) return;
    if (editing.id) save(items.map((c) => (c.id === editing.id ? editing : c)), "Category updated");
    else save([...items, { ...editing, id: uid() }], "Category added");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Categories"
        sub="Add unlimited categories — they appear as filters in Publications."
        right={<Btn size="sm" onClick={() => setEditing({ id: "", name: "", color: "#0b6b4f" })}><Plus size={15} /> New category</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((c, i) => (
          <Row key={c.id}>
            <MoveBtns index={i} len={items.length} onMove={(d) => save(move(items, i, d))} />
            <span className="h-9 w-9 shrink-0 rounded-full border-4 border-white shadow" style={{ background: c.color }} />
            <div className="min-w-0 flex-1">
              <div className="font-semibold">{c.name}</div>
              <div className="text-xs tx-faint">{data.publications.filter((p) => p.category === c.name).length} works</div>
            </div>
            <button type="button" className={ACT} onClick={() => setEditing(c)}><Pencil size={15} /></button>
            <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={() => setDelId(c.id)}><Trash2 size={15} /></button>
          </Row>
        ))}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete category?"
        message="Works in this category stay published, but the filter is removed."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((c) => c.id !== delId), "Category deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit category" : "New category"}</h3>
            <div className="mt-5 space-y-4">
              <Field label="Name"><TextInput value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} placeholder="e.g. Poem, Naat, Reportage…" /></Field>
              <Field label="Badge color">
                <input type="color" value={editing.color} onChange={(e) => setEditing({ ...editing, color: e.target.value })} className="h-11 w-full cursor-pointer rounded-xl border line" />
              </Field>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function MagazinesEditor() {
  const { items, save } = useCrud("magazines");
  const { toast } = useSite();
  const [editing, setEditing] = useState<Magazine | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const blank: Magazine = { id: "", title: "", issue: "", date: todayISO(), description: "", cover: "", pdf: "", downloads: 0, visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.title.trim()) {
      toast("Magazine title is required.", "error");
      return;
    }
    if (editing.id) save(items.map((m) => (m.id === editing.id ? editing : m)), "Magazine updated");
    else save([...items, { ...editing, id: uid() }], "Magazine added");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Magazines"
        sub="Covers + PDF — attach the PDF from device storage or paste a link."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> New issue</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((m) => (
          <Row key={m.id}>
            <ImgBox src={m.cover} alt="" className="h-16 w-12 shrink-0 rounded-lg" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{m.title}</div>
              <div className="mt-0.5 truncate text-xs tx-faint">{m.issue} · {fmtDate(m.date)} · {m.pdf ? (m.pdf.startsWith("data:") ? "PDF attached" : "PDF linked") : "no PDF yet"}</div>
            </div>
            <Chip>{m.downloads} dl</Chip>
            <EditActions
              vis={m.visible}
              onVis={(v) => save(items.map((x) => (x.id === m.id ? { ...x, visible: v } : x)))}
              onEdit={() => setEditing(m)}
              onDel={() => setDelId(m.id)}
            />
          </Row>
        ))}
        {items.length === 0 && <p className="py-10 text-center text-sm tx-faint">No issues yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this issue?"
        message="The cover and PDF reference are removed from the site."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((m) => m.id !== delId), "Magazine deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)} wide>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit issue" : "New issue"}</h3>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Field label="Title"><TextInput value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} placeholder="e.g. NOOR" /></Field>
              <Field label="Issue / edition"><TextInput value={editing.issue} onChange={(e) => setEditing({ ...editing, issue: e.target.value })} placeholder="Issue 04 · Meelad Edition" /></Field>
              <Field label="Publish date"><TextInput type="date" value={dateInput(editing.date)} onChange={(e) => setEditing({ ...editing, date: fromDateInput(e.target.value, editing.date) })} /></Field>
              <div className="flex items-end pb-1"><Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible on site" /></div>
              <div className="sm:col-span-2">
                <Field label="Description"><TextArea value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className="min-h-[80px]" /></Field>
              </div>
              <FileOrLink label="Cover thumbnail" kind="image" value={editing.cover} onChange={(v) => setEditing({ ...editing, cover: v })} hint="upload or link" />
              <FileOrLink label="Magazine PDF" kind="pdf" value={editing.pdf} onChange={(v) => setEditing({ ...editing, pdf: v })} hint="device or link · ≤ 8MB" maxMB={8} />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save issue</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function GalleryEditor() {
  const { items, save, toast } = useCrud("albums");
  const [editing, setEditing] = useState<Album | null>(null);
  const [delId, setDelId] = useState<string | null>(null);
  const [link, setLink] = useState("");
  const multiRef = useRef<HTMLInputElement>(null);

  const blank: Album = { id: "", title: "", date: todayISO(), cover: "", images: [], visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.title.trim()) {
      toast("Album title is required.", "error");
      return;
    }
    const cover = editing.cover || editing.images[0] || "";
    if (editing.id) save(items.map((a) => (a.id === editing.id ? { ...editing, cover } : a)), "Album updated");
    else save([{ ...editing, cover, id: uid() }, ...items], "Album created");
    setEditing(null);
  };

  const addFiles = async (files: FileList | null) => {
    if (!files || !editing) return;
    const out: string[] = [];
    for (const f of Array.from(files)) out.push(await processImageFile(f, 1280, 0.8));
    setEditing({ ...editing, images: [...editing.images, ...out] });
    toast(`${out.length} photo${out.length > 1 ? "s" : ""} added from device`);
  };

  return (
    <div>
      <AdminHead
        title="Photo gallery"
        sub="Event albums — upload photos straight from device storage or paste links."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> New album</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((a, i) => (
          <Row key={a.id}>
            <MoveBtns index={i} len={items.length} onMove={(d) => save(move(items, i, d))} />
            <ImgBox src={a.cover} alt="" className="h-14 w-14 shrink-0 rounded-xl" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{a.title}</div>
              <div className="mt-0.5 text-xs tx-faint"><Images size={10} className="mr-1 inline" />{a.images.length} photos · {fmtDate(a.date)}</div>
            </div>
            <EditActions
              vis={a.visible}
              onVis={(v) => save(items.map((x) => (x.id === a.id ? { ...x, visible: v } : x)))}
              onEdit={() => setEditing(a)}
              onDel={() => setDelId(a.id)}
            />
          </Row>
        ))}
        {items.length === 0 && <p className="py-10 text-center text-sm tx-faint">No albums yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this album?"
        message="All photos inside it are removed from the site."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((a) => a.id !== delId), "Album deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)} wide>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit album" : "New album"}</h3>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Field label="Album title"><TextInput value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} placeholder="e.g. Arts Day 2026" /></Field>
              <Field label="Date"><TextInput type="date" value={dateInput(editing.date)} onChange={(e) => setEditing({ ...editing, date: fromDateInput(e.target.value, editing.date) })} /></Field>
              <div className="sm:col-span-2">
                <FileOrLink label="Cover photo" kind="image" value={editing.cover} onChange={(v) => setEditing({ ...editing, cover: v })} hint="defaults to first photo" />
              </div>
              <div className="sm:col-span-2">
                <Field label={`Photos (${editing.images.length})`} hint="upload many at once">
                  <div className="space-y-3">
                    {editing.images.length > 0 && (
                      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                        {editing.images.map((img, i) => (
                          <div key={i} className="group relative overflow-hidden rounded-xl">
                            <img src={img} alt="" className="aspect-square w-full object-cover" />
                            <button
                              type="button"
                              onClick={() => setEditing({ ...editing, images: editing.images.filter((_, x) => x !== i) })}
                              className="absolute right-1 top-1 rounded-full bg-black/60 p-1.5 text-white opacity-0 transition group-hover:opacity-100"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-2">
                      <Btn type="button" variant="outline" size="sm" onClick={() => multiRef.current?.click()}>
                        <Plus size={14} /> Upload from device
                      </Btn>
                      <div className="flex min-w-[220px] flex-1 gap-2">
                        <TextInput placeholder="…or paste image link" value={link} onChange={(e) => setLink(e.target.value)} />
                        <Btn
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (link.trim()) {
                              setEditing({ ...editing, images: [...editing.images, link.trim()] });
                              setLink("");
                            }
                          }}
                        >
                          Add
                        </Btn>
                      </div>
                    </div>
                    <input ref={multiRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => { void addFiles(e.target.files); e.target.value = ""; }} />
                  </div>
                </Field>
              </div>
              <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible on site" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save album</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function VideosEditor() {
  const { items, save } = useCrud("videos");
  const { toast } = useSite();
  const [editing, setEditing] = useState<VideoItem | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const blank: VideoItem = { id: "", title: "", url: "", thumbnail: "", category: "Events", date: todayISO(), views: 0, visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.title.trim() || !editing.url.trim()) {
      toast("Title and video source are required.", "error");
      return;
    }
    if (editing.id) save(items.map((v) => (v.id === editing.id ? editing : v)), "Video updated");
    else save([{ ...editing, id: uid() }, ...items], "Video added");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Videos"
        sub="YouTube / direct links, or upload a short clip from device storage."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> New video</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((v) => (
          <Row key={v.id}>
            <ImgBox src={v.thumbnail || ytThumb(v.url)} alt="" className="h-14 w-20 shrink-0 rounded-xl" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{v.title}</div>
              <div className="mt-0.5 truncate text-xs tx-faint">{v.category} · {v.views} views · {fmtDate(v.date)}</div>
            </div>
            <EditActions
              vis={v.visible}
              onVis={(x) => save(items.map((y) => (y.id === v.id ? { ...y, visible: x } : y)))}
              onEdit={() => setEditing(v)}
              onDel={() => setDelId(v.id)}
            />
          </Row>
        ))}
        {items.length === 0 && <p className="py-10 text-center text-sm tx-faint">No videos yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this video?"
        message="It disappears from the video hub."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((v) => v.id !== delId), "Video deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)} wide>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit video" : "New video"}</h3>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Field label="Title"><TextInput value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} /></Field>
              </div>
              <div className="sm:col-span-2">
                <FileOrLink
                  label="Video source"
                  kind="video"
                  value={editing.url}
                  onChange={(x) => setEditing({ ...editing, url: x })}
                  hint="YouTube / mp4 link · or upload ≤ 6MB from device"
                  maxMB={6}
                />
              </div>
              <div className="sm:col-span-2">
                <FileOrLink
                  label="Thumbnail"
                  kind="image"
                  value={editing.thumbnail}
                  onChange={(x) => setEditing({ ...editing, thumbnail: x })}
                  hint="auto-fetched from YouTube when empty"
                />
              </div>
              <Field label="Category"><TextInput value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} /></Field>
              <Field label="Date"><TextInput type="date" value={dateInput(editing.date)} onChange={(e) => setEditing({ ...editing, date: fromDateInput(e.target.value, editing.date) })} /></Field>
              <Toggle checked={editing.visible} onChange={(x) => setEditing({ ...editing, visible: x })} label="Visible on site" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save video</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function EventsEditor() {
  const { items, save } = useCrud("events");
  const { toast } = useSite();
  const [editing, setEditing] = useState<EventItem | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const blank: EventItem = { id: "", title: "", date: todayISO(), time: "", venue: "", description: "", poster: "", visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.title.trim()) {
      toast("Event title is required.", "error");
      return;
    }
    if (editing.id) save(items.map((e) => (e.id === editing.id ? editing : e)), "Event updated");
    else save([...items, { ...editing, id: uid() }], "Event added");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Events"
        sub="Programs with date, venue, description and poster."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> New event</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((e) => {
          const d = new Date(e.date);
          return (
            <Row key={e.id}>
              <span className="flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-xl bg-primary tx-on">
                <span className="font-display text-xl font-bold leading-none">{d.getDate()}</span>
                <span className="text-[9px] font-bold uppercase tracking-widest opacity-80">{d.toLocaleDateString("en-IN", { month: "short" })}</span>
              </span>
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold">{e.title}</div>
                <div className="mt-0.5 truncate text-xs tx-faint">{e.venue}{e.time ? ` · ${e.time}` : ""}</div>
              </div>
              <EditActions
                vis={e.visible}
                onVis={(x) => save(items.map((y) => (y.id === e.id ? { ...y, visible: x } : y)))}
                onEdit={() => setEditing(e)}
                onDel={() => setDelId(e.id)}
              />
            </Row>
          );
        })}
        {items.length === 0 && <p className="py-10 text-center text-sm tx-faint">No events yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this event?"
        message="It is removed from the events calendar."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((e) => e.id !== delId), "Event deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)} wide>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit event" : "New event"}</h3>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Field label="Title"><TextInput value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} /></Field>
              </div>
              <Field label="Date"><TextInput type="date" value={dateInput(editing.date)} onChange={(e) => setEditing({ ...editing, date: fromDateInput(e.target.value, editing.date) })} /></Field>
              <Field label="Time"><TextInput value={editing.time} onChange={(e) => setEditing({ ...editing, time: e.target.value })} placeholder="10:00 AM" /></Field>
              <Field label="Venue"><TextInput value={editing.venue} onChange={(e) => setEditing({ ...editing, venue: e.target.value })} placeholder="Main Auditorium" /></Field>
              <div className="flex items-end pb-1"><Toggle checked={editing.visible} onChange={(x) => setEditing({ ...editing, visible: x })} label="Visible on site" /></div>
              <div className="sm:col-span-2">
                <Field label="Description"><TextArea value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className="min-h-[80px]" /></Field>
              </div>
              <div className="sm:col-span-2">
                <FileOrLink label="Poster" kind="image" value={editing.poster} onChange={(x) => setEditing({ ...editing, poster: x })} hint="optional · upload or link" />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save event</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
