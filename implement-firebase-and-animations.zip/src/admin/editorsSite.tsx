import { useRef, useState } from "react";
import {
  Download, Eye, GripVertical, KeyRound, Megaphone, Pencil, Plus, RotateCcw, Save, Star, Trash2, Upload,
} from "lucide-react";
import {
  Btn, Chip, ColorField, ConfirmDialog, Field, FileOrLink, ICON_NAMES, IconByName, Modal, SelectInput, TextArea, TextInput, Toggle,
} from "../components/ui";
import { seedData } from "../seed";
import { useSite } from "../store";
import { cx, todayISO, uid } from "../utils";
import type { HomeButton, HomeSection, Notice, PageKey, PopupCfg, SiteData, Theme, TickerCfg, TickerItem } from "../types";
import { ACT, AdminHead, MoveBtns, PANEL, Row, VisToggle, move, useCrud } from "./shared";

const PAGE_OPTIONS: { value: PageKey; label: string }[] = [
  { value: "home", label: "Home" },
  { value: "works", label: "Publications" },
  { value: "magazines", label: "Magazines" },
  { value: "gallery", label: "Gallery" },
  { value: "videos", label: "Videos" },
  { value: "events", label: "Events" },
  { value: "notices", label: "Notices" },
  { value: "awards", label: "Awards" },
  { value: "committee", label: "Committee" },
  { value: "forums", label: "Forums" },
  { value: "report", label: "Report" },
  { value: "about", label: "About" },
];

/* ================================================================== */
export function LayoutEditor() {
  const { data, setSection, toast } = useSite();
  const layout = data.homeLayout;
  const buttons = data.homeButtons;
  const [editing, setEditing] = useState<HomeButton | null>(null);
  const [delId, setDelId] = useState<string | null>(null);
  const [iconPick, setIconPick] = useState<string>("BookOpen");

  const saveLayout = (next: HomeSection[], msg?: string) => {
    setSection("homeLayout", next, true);
    if (msg) toast(msg);
  };
  const saveButtons = (next: HomeButton[], msg?: string) => {
    setSection("homeButtons", next, true);
    if (msg) toast(msg);
  };

  const openAdd = () => {
    setIconPick("BookOpen");
    setEditing({ id: "", label: "", icon: "BookOpen", target: "works", visible: true });
  };

  const commit = () => {
    if (!editing) return;
    if (!editing.label.trim()) {
      toast("Button label is required.", "error");
      return;
    }
    const withIcon = { ...editing, icon: iconPick };
    if (editing.id) saveButtons(buttons.map((b) => (b.id === editing.id ? withIcon : b)), "Button updated");
    else saveButtons([...buttons, { ...withIcon, id: uid() }], "Button added to homepage");
    setEditing(null);
  };

  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <div className={PANEL}>
        <AdminHead title="Home sections" sub="Reorder or hide every section of the homepage." />
        <div className="grid gap-2">
          {layout.map((s, i) => (
            <Row key={s.id}>
              <GripVertical size={15} className="shrink-0 opacity-40" />
              <MoveBtns index={i} len={layout.length} onMove={(d) => saveLayout(move(layout, i, d))} />
              <span className={cx("flex-1 text-sm font-semibold", !s.visible && "opacity-40 line-through")}>{s.label}</span>
              <VisToggle v={s.visible} onChange={(v) => saveLayout(layout.map((x) => (x.id === s.id ? { ...x, visible: v } : x)))} />
            </Row>
          ))}
        </div>
      </div>

      <div className={PANEL}>
        <AdminHead
          title="Home quick buttons"
          sub="Add, edit, hide or reorder the shortcut buttons."
          right={<Btn size="sm" onClick={openAdd}><Plus size={15} /> Add button</Btn>}
        />
        <div className="grid gap-2">
          {buttons.map((b, i) => (
            <Row key={b.id}>
              <MoveBtns index={i} len={buttons.length} onMove={(d) => saveButtons(move(buttons, i, d))} />
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[color-mix(in_srgb,var(--primary)_10%,transparent)] tx-primary">
                <IconByName name={b.icon} size={17} />
              </span>
              <span className="min-w-0 flex-1">
                <span className={cx("block truncate text-sm font-semibold", !b.visible && "opacity-40 line-through")}>{b.label}</span>
                <span className="mt-0.5 block"><Chip>{PAGE_OPTIONS.find((p) => p.value === b.target)?.label || b.target}</Chip></span>
              </span>
              <VisToggle v={b.visible} onChange={(v) => saveButtons(buttons.map((x) => (x.id === b.id ? { ...x, visible: v } : x)))} />
              <button type="button" className={ACT} onClick={() => { setIconPick(b.icon); setEditing(b); }}><Pencil size={15} /></button>
              <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={() => setDelId(b.id)}><Trash2 size={15} /></button>
            </Row>
          ))}
          {buttons.length === 0 && <p className="py-8 text-center text-sm tx-faint">No quick buttons — add one.</p>}
        </div>
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this button?"
        message="It disappears from the homepage."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          saveButtons(buttons.filter((b) => b.id !== delId), "Button deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit button" : "Add button"}</h3>
            <div className="mt-5 space-y-4">
              <Field label="Label"><TextInput value={editing.label} onChange={(e) => setEditing({ ...editing, label: e.target.value })} placeholder="e.g. Explore Works" /></Field>
              <Field label="Icon">
                <div className="grid grid-cols-5 gap-2 sm:grid-cols-7">
                  {ICON_NAMES.map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setIconPick(n)}
                      title={n}
                      className={cx(
                        "flex h-11 items-center justify-center rounded-xl border transition",
                        iconPick === n ? "border-[var(--primary)] bg-[color-mix(in_srgb,var(--primary)_10%,transparent)] tx-primary" : "line tx-soft hover:soft-panel"
                      )}
                    >
                      <IconByName name={n} size={17} />
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="Opens page">
                <SelectInput value={editing.target} onChange={(e) => setEditing({ ...editing, target: e.target.value })}>
                  {PAGE_OPTIONS.map((p) => (
                    <option key={p.value} value={p.value}>{p.label}</option>
                  ))}
                </SelectInput>
              </Field>
              <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible on homepage" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save button</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function AnnounceEditor() {
  const { data, setSection, toast } = useSite();
  const s = data.settings;
  const t = s.ticker;
  const [editing, setEditing] = useState<TickerItem | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const updateTicker = (patch: Partial<TickerCfg>, msg?: string) => {
    setSection("settings", { ...s, ticker: { ...t, ...patch } }, true);
    if (msg) toast(msg);
  };

  const commitItem = () => {
    if (!editing) return;
    if (!editing.text.trim()) {
      toast("Ticker text is required.", "error");
      return;
    }
    if (editing.id) {
      updateTicker({ items: t.items.map((x) => (x.id === editing.id ? editing : x)) }, "Ticker item updated — live now");
    } else {
      updateTicker({ items: [...t.items, { ...editing, text: editing.text.trim(), id: uid() }] }, "Ticker item added — live now");
    }
    setEditing(null);
  };

  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <div className={PANEL}>
        <AdminHead
          title="Notification ticker"
          sub="The moving strip at the very top — starts automatically on page load."
          right={<Btn size="sm" onClick={() => setEditing({ id: "", text: "", visible: true })}><Plus size={15} /> Add item</Btn>}
        />
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
            <Toggle checked={t.enabled} onChange={(v) => updateTicker({ enabled: v }, v ? "Ticker switched on" : "Ticker switched off")} label="Show ticker" />
            <Field label="Direction">
              <SelectInput value={t.direction} onChange={(e) => updateTicker({ direction: e.target.value as TickerCfg["direction"] })}>
                <option value="rtl">Right → Left</option>
                <option value="ltr">Left → Right</option>
              </SelectInput>
            </Field>
            <Field label="Speed">
              <SelectInput value={t.speed} onChange={(e) => updateTicker({ speed: e.target.value as TickerCfg["speed"] })}>
                <option value="slow">Slow</option>
                <option value="normal">Normal</option>
                <option value="fast">Fast</option>
              </SelectInput>
            </Field>
          </div>
          <div className="grid gap-2">
            {t.items.map((item, i) => (
              <Row key={item.id}>
                <MoveBtns index={i} len={t.items.length} onMove={(d) => updateTicker({ items: move(t.items, i, d) })} />
                <Megaphone size={13} className="shrink-0 tx-accent" />
                <span className={cx("min-w-0 flex-1 truncate text-sm", !item.visible && "opacity-40 line-through")}>{item.text}</span>
                <VisToggle
                  v={item.visible}
                  onChange={(v) => updateTicker({ items: t.items.map((x) => (x.id === item.id ? { ...x, visible: v } : x)) })}
                />
                <button type="button" className={ACT} title="Edit" onClick={() => setEditing(item)}>
                  <Pencil size={14} />
                </button>
                <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} title="Delete" onClick={() => setDelId(item.id)}>
                  <Trash2 size={14} />
                </button>
              </Row>
            ))}
            {t.items.length === 0 && (
              <p className="rounded-2xl border border-dashed line py-8 text-center text-sm tx-faint">
                No ticker items yet — add your first announcement.
              </p>
            )}
          </div>
          <p className="text-xs tx-faint">Hidden items stay saved but don't scroll on the site. Hovering the ticker pauses it for readers.</p>
        </div>
      </div>
      <NoticesPanel />

      <ConfirmDialog
        open={!!delId}
        title="Delete ticker item?"
        message="This announcement is removed from the moving strip."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          updateTicker({ items: t.items.filter((x) => x.id !== delId) }, "Ticker item deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit ticker item" : "Add ticker item"}</h3>
            <div className="mt-5 space-y-4">
              <Field label="Announcement text">
                <TextArea
                  value={editing.text}
                  onChange={(e) => setEditing({ ...editing, text: e.target.value })}
                  placeholder="e.g. Literary Competition registrations close on August 25"
                  className="min-h-[90px]"
                />
              </Field>
              <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible in ticker" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commitItem}>{editing.id ? "Save changes" : "Add to ticker"}</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function NoticesPanel() {
  const { items, save } = useCrud("notices");
  const { toast } = useSite();
  const [editing, setEditing] = useState<Notice | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const blank: Notice = { id: "", text: "", link: "", important: false, date: todayISO(), visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.text.trim()) {
      toast("Notice text is required.", "error");
      return;
    }
    if (editing.id) save(items.map((n) => (n.id === editing.id ? editing : n)), "Notice updated");
    else save([{ ...editing, id: uid() }, ...items], "Notice published");
    setEditing(null);
  };

  return (
    <div className={PANEL}>
      <AdminHead title="Notice board" sub="Important notices pin to the top." right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> New notice</Btn>} />
      <div className="grid gap-2">
        {items.map((n) => (
          <Row key={n.id}>
            <button
              type="button"
              className={ACT}
              title="Toggle important"
              onClick={() => save(items.map((x) => (x.id === n.id ? { ...x, important: !x.important } : x)))}
            >
              <Star size={15} className={n.important ? "fill-amber-400 text-amber-400" : "opacity-40"} />
            </button>
            <span className="min-w-0 flex-1 truncate text-sm">{n.text}</span>
            <VisToggle v={n.visible} onChange={(v) => save(items.map((x) => (x.id === n.id ? { ...x, visible: v } : x)))} />
            <button type="button" className={ACT} onClick={() => setEditing(n)}><Pencil size={15} /></button>
            <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={() => setDelId(n.id)}><Trash2 size={15} /></button>
          </Row>
        ))}
        {items.length === 0 && <p className="py-8 text-center text-sm tx-faint">No notices yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this notice?"
        message="It is removed from the notice board."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((n) => n.id !== delId), "Notice deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit notice" : "New notice"}</h3>
            <div className="mt-5 space-y-4">
              <Field label="Notice text"><TextArea value={editing.text} onChange={(e) => setEditing({ ...editing, text: e.target.value })} className="min-h-[90px]" /></Field>
              <Field label="Attachment link" hint="optional"><TextInput value={editing.link} onChange={(e) => setEditing({ ...editing, link: e.target.value })} placeholder="https://…" /></Field>
              <div className="flex gap-8">
                <Toggle checked={editing.important} onChange={(v) => setEditing({ ...editing, important: v })} label="Important" />
                <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible" />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Publish notice</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function PopupEditor() {
  const { data, setSection, toast } = useSite();
  const s = data.settings;
  const p = s.popup;
  const [preview, setPreview] = useState(false);

  const update = (patch: Partial<PopupCfg>, msg?: string) => {
    setSection("settings", { ...s, popup: { ...p, ...patch } }, true);
    if (msg) toast(msg);
  };

  return (
    <div className="mx-auto max-w-3xl">
      <AdminHead
        title="Popup alert"
        sub="A welcome popup with optional image — shown when the site opens."
        right={<Btn size="sm" variant="outline" onClick={() => setPreview(true)}><Eye size={15} /> Preview</Btn>}
      />
      <div className={cx(PANEL, "space-y-4")}>
        <Toggle checked={p.enabled} onChange={(v) => update({ enabled: v }, v ? "Popup switched on" : "Popup switched off")} label="Popup enabled" />
        <Field label="Title"><TextInput value={p.title} onChange={(e) => update({ title: e.target.value })} /></Field>
        <Field label="Message"><TextArea value={p.message} onChange={(e) => update({ message: e.target.value })} className="min-h-[90px]" /></Field>
        <FileOrLink label="Popup image" kind="image" value={p.image} onChange={(v) => update({ image: v })} hint="optional · upload or link" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Button text"><TextInput value={p.buttonText} onChange={(e) => update({ buttonText: e.target.value })} /></Field>
          <Field label="Button opens">
            <SelectInput value={p.buttonTarget} onChange={(e) => update({ buttonTarget: e.target.value })}>
              {PAGE_OPTIONS.map((x) => (
                <option key={x.value} value={x.value}>{x.label}</option>
              ))}
            </SelectInput>
          </Field>
        </div>
        <Toggle checked={p.showOnce} onChange={(v) => update({ showOnce: v })} label="Show only once per visit" />
        <Btn size="sm" onClick={() => toast("Popup settings saved — live now.")}><Save size={14} /> Confirm saved</Btn>
      </div>

      <Modal open={preview} onClose={() => setPreview(false)}>
        <div className="text-center">
          {p.image && <img src={p.image} alt="" className="mb-4 h-40 w-full rounded-2xl object-cover" />}
          <h3 className="font-display text-xl font-bold">{p.title || "Popup title"}</h3>
          <p className="mt-2 text-sm tx-soft">{p.message || "Popup message preview…"}</p>
          <div className="mt-5 rounded-full bg-primary px-6 py-3 text-sm font-bold tx-on">{p.buttonText || "Button"}</div>
        </div>
      </Modal>
    </div>
  );
}

/* ================================================================== */
const PRESETS: { name: string; t: Theme }[] = [
  {
    name: "Emerald Ivory",
    t: { bg: "#faf8f2", surface: "#ffffff", ink: "#14211b", primary: "#0b6b4f", onPrimary: "#ffffff", accent: "#c9a24b", tickerBg: "#14211b", tickerText: "#f3e8c8" },
  },
  {
    name: "Midnight Gold",
    t: { bg: "#101418", surface: "#1b222b", ink: "#f0ead9", primary: "#c9a24b", onPrimary: "#101418", accent: "#7fb8a4", tickerBg: "#c9a24b", tickerText: "#101418" },
  },
  {
    name: "Ocean Sand",
    t: { bg: "#f2f7f8", surface: "#ffffff", ink: "#0f2530", primary: "#0e7490", onPrimary: "#ffffff", accent: "#d97706", tickerBg: "#0f2530", tickerText: "#cde7ee" },
  },
  {
    name: "Rosewood",
    t: { bg: "#faf5f2", surface: "#ffffff", ink: "#2b1a17", primary: "#9d3b3b", onPrimary: "#ffffff", accent: "#d4a017", tickerBg: "#2b1a17", tickerText: "#f3dcc8" },
  },
];

export function ThemeEditor() {
  const { data, setSection, toast } = useSite();
  const s = data.settings;
  const [theme, setTheme] = useState<Theme>(s.theme);
  const [f, setF] = useState({
    siteName: s.siteName, siteUnit: s.siteUnit, tagline: s.tagline, logo: s.logo, showLogo: s.showLogo !== false,
    heroImage: s.heroImage, showHeroImage: s.showHeroImage === true,
    heroTitleSize: s.heroTitleSize || "grand", heroTitleFont: s.heroTitleFont || "display",
    heroTitleColor: s.heroTitleColor || "", heroAccentColor: s.heroAccentColor || "",
    heroBadge: s.heroBadge, heroTitle: s.heroTitle, heroAccent: s.heroAccent, heroSubtitle: s.heroSubtitle,
    about: s.about, vision: s.vision, mission: s.mission, footerText: s.footerText,
    email: s.email, phone: s.phone, address: s.address,
  });

  const saveAll = () => {
    setSection("settings", { ...s, ...f, theme }, true);
    toast("Theme & branding updated — live everywhere.");
  };

  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <div className={cx(PANEL, "space-y-4")}>
        <AdminHead title="Colors" sub="Homepage background, buttons, ticker — redesign in one click." />
        <div>
          <div className="mb-2 text-[11px] font-bold uppercase tracking-[0.2em] tx-faint">Presets</div>
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <button
                key={p.name}
                onClick={() => setTheme(p.t)}
                className="flex items-center gap-2 rounded-full border line px-3 py-2 text-xs font-semibold transition hover:soft-panel"
              >
                <span className="flex -space-x-1">
                  <span className="h-4 w-4 rounded-full border border-white" style={{ background: p.t.primary }} />
                  <span className="h-4 w-4 rounded-full border border-white" style={{ background: p.t.accent }} />
                  <span className="h-4 w-4 rounded-full border border-white" style={{ background: p.t.bg }} />
                </span>
                {p.name}
              </button>
            ))}
          </div>
        </div>
        <div className="grid gap-2.5 sm:grid-cols-2">
          <ColorField label="Page background" value={theme.bg} onChange={(v) => setTheme({ ...theme, bg: v })} />
          <ColorField label="Card surface" value={theme.surface} onChange={(v) => setTheme({ ...theme, surface: v })} />
          <ColorField label="Text / ink" value={theme.ink} onChange={(v) => setTheme({ ...theme, ink: v })} />
          <ColorField label="Primary (buttons)" value={theme.primary} onChange={(v) => setTheme({ ...theme, primary: v })} />
          <ColorField label="Text on buttons" value={theme.onPrimary} onChange={(v) => setTheme({ ...theme, onPrimary: v })} />
          <ColorField label="Accent" value={theme.accent} onChange={(v) => setTheme({ ...theme, accent: v })} />
          <ColorField label="Ticker background" value={theme.tickerBg} onChange={(v) => setTheme({ ...theme, tickerBg: v })} />
          <ColorField label="Ticker text" value={theme.tickerText} onChange={(v) => setTheme({ ...theme, tickerText: v })} />
        </div>
        <div className="flex flex-wrap gap-3">
          <Btn size="sm" onClick={saveAll}><Save size={14} /> Apply theme & branding</Btn>
          <Btn size="sm" variant="ghost" onClick={() => { setTheme(seedData.settings.theme); setF({ ...f, ...seedData.settings, theme: undefined } as typeof f); toast("Editing fields reset to defaults — press Apply to publish.", "info"); }}>
            <RotateCcw size={14} /> Reset
          </Btn>
        </div>
      </div>

      <div className={cx(PANEL, "space-y-4")}>
        <AdminHead title="Branding & texts" sub="Logo, hero and about texts — including the animated headings." />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Site name"><TextInput value={f.siteName} onChange={(e) => setF({ ...f, siteName: e.target.value })} /></Field>
          <Field label="Unit / place"><TextInput value={f.siteUnit} onChange={(e) => setF({ ...f, siteUnit: e.target.value })} /></Field>
        </div>
        <FileOrLink label="Logo" kind="image" value={f.logo} onChange={(v) => setF({ ...f, logo: v })} hint="upload from device · shown in header & footer" />
        <div className="flex flex-wrap gap-x-8 gap-y-3">
          <Toggle checked={f.showLogo} onChange={(v) => setF({ ...f, showLogo: v })} label="Show logo image in header" />
        </div>
        <FileOrLink label="Hero image (right of homepage title)" kind="image" value={f.heroImage} onChange={(v) => setF({ ...f, heroImage: v })} hint="no default — upload to show, or keep hidden" />
        <Toggle checked={f.showHeroImage} onChange={(v) => setF({ ...f, showHeroImage: v })} label="Show hero image on homepage" />
        <div className="rounded-2xl border border-dashed line p-4">
          <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] tx-faint">Animated hero text</div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Font style">
              <SelectInput value={f.heroTitleFont} onChange={(e) => setF({ ...f, heroTitleFont: e.target.value as typeof f.heroTitleFont })}>
                <option value="display">Elegant Serif (Fraunces)</option>
                <option value="sans">Modern Sans (Outfit)</option>
                <option value="ar">Arabic (Amiri)</option>
              </SelectInput>
            </Field>
            <Field label="Size">
              <SelectInput value={f.heroTitleSize} onChange={(e) => setF({ ...f, heroTitleSize: e.target.value as typeof f.heroTitleSize })}>
                <option value="compact">Compact</option>
                <option value="classic">Classic</option>
                <option value="grand">Grand</option>
                <option value="massive">Massive</option>
              </SelectInput>
            </Field>
            <ColorField label="Title color" value={f.heroTitleColor || "#14211b"} onChange={(v) => setF({ ...f, heroTitleColor: v })} />
            <ColorField label="Accent word color" value={f.heroAccentColor || "#c9a24b"} onChange={(v) => setF({ ...f, heroAccentColor: v })} />
          </div>
          <button
            onClick={() => setF({ ...f, heroTitleColor: "", heroAccentColor: "" })}
            className="mt-3 text-[11px] font-bold uppercase tracking-widest tx-faint transition hover:tx-primary"
          >
            Reset colors to theme default
          </button>
        </div>
        <Field label="Tagline"><TextInput value={f.tagline} onChange={(e) => setF({ ...f, tagline: e.target.value })} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Hero badge"><TextInput value={f.heroBadge} onChange={(e) => setF({ ...f, heroBadge: e.target.value })} /></Field>
          <Field label="Hero title (animated)"><TextInput value={f.heroTitle} onChange={(e) => setF({ ...f, heroTitle: e.target.value })} /></Field>
          <Field label="Hero accent word (animated)"><TextInput value={f.heroAccent} onChange={(e) => setF({ ...f, heroAccent: e.target.value })} /></Field>
          <Field label="Hero subtitle"><TextInput value={f.heroSubtitle} onChange={(e) => setF({ ...f, heroSubtitle: e.target.value })} /></Field>
        </div>
        <Field label="About"><TextArea value={f.about} onChange={(e) => setF({ ...f, about: e.target.value })} className="min-h-[110px]" /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Vision"><TextArea value={f.vision} onChange={(e) => setF({ ...f, vision: e.target.value })} className="min-h-[80px]" /></Field>
          <Field label="Mission"><TextArea value={f.mission} onChange={(e) => setF({ ...f, mission: e.target.value })} className="min-h-[80px]" /></Field>
        </div>
        <Field label="Footer note"><TextInput value={f.footerText} onChange={(e) => setF({ ...f, footerText: e.target.value })} /></Field>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Email"><TextInput value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
          <Field label="Phone"><TextInput value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label="Address"><TextInput value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></Field>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
const RULES_SNIPPET = `{
  "rules": {
    ".read": true,
    ".write": true
  }
}`;

export function SettingsEditor() {
  const { data, setSection, toast, connected, dbError } = useSite();
  const fileRef = useRef<HTMLInputElement>(null);
  const [cur, setCur] = useState("");
  const [newU, setNewU] = useState("");
  const [newP, setNewP] = useState("");
  const [confirmP, setConfirmP] = useState("");
  const [resetOpen, setResetOpen] = useState(false);
  const auth = data.settings.auth;

  const saveCreds = () => {
    if (cur !== auth.password) {
      toast("Current password is incorrect.", "error");
      return;
    }
    if (!newU.trim() || newP.length < 4) {
      toast("Username is required and the new password needs 4+ characters.", "error");
      return;
    }
    if (newP !== confirmP) {
      toast("New passwords do not match.", "error");
      return;
    }
    setSection("settings", { ...data.settings, auth: { username: newU.trim(), password: newP } }, true);
    setCur(""); setNewU(""); setNewP(""); setConfirmP("");
    toast("Credentials updated — use them on your next login.");
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `muhyissunna-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast("Backup downloaded.");
  };

  const importData = async (file: File | undefined) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as Record<string, unknown>;
      const keys = Object.keys(seedData) as (keyof SiteData)[];
      keys.forEach((k) => {
        if (parsed[k] !== undefined) setSection(k, parsed[k] as never, true);
      });
      toast("Backup imported — the site is updated.");
    } catch {
      toast("That file is not a valid backup.", "error");
    }
  };

  const resetAll = () => {
    (Object.keys(seedData) as (keyof SiteData)[]).forEach((k) => setSection(k, seedData[k] as never, true));
    setResetOpen(false);
    toast("Everything reset to the original defaults.");
  };

  return (
    <div className="grid gap-6 xl:grid-cols-2">
      <div className={cx(PANEL, "space-y-4")}>
        <AdminHead title="Login credentials" sub="Change the admin username & password anytime." />
        <div className="flex items-center gap-3 rounded-2xl soft-panel p-4">
          <KeyRound size={18} className="tx-primary" />
          <p className="text-sm tx-soft">Default credentials are never displayed on the login screen.</p>
        </div>
        <Field label="Current password"><TextInput type="password" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" /></Field>
        <Field label="New username"><TextInput value={newU} onChange={(e) => setNewU(e.target.value)} autoComplete="off" /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="New password"><TextInput type="password" value={newP} onChange={(e) => setNewP(e.target.value)} autoComplete="new-password" /></Field>
          <Field label="Confirm new password"><TextInput type="password" value={confirmP} onChange={(e) => setConfirmP(e.target.value)} autoComplete="new-password" /></Field>
        </div>
        <Btn size="sm" onClick={saveCreds}><Save size={14} /> Update credentials</Btn>
      </div>

      <div className="space-y-6">
        <div className={cx(PANEL, "space-y-4")}>
          <AdminHead title="Backup & restore" sub="Download everything as JSON, restore it later, or reset to defaults." />
          <div className="flex flex-wrap gap-3">
            <Btn size="sm" variant="outline" onClick={exportData}><Download size={14} /> Export backup</Btn>
            <Btn size="sm" variant="outline" onClick={() => fileRef.current?.click()}><Upload size={14} /> Import backup</Btn>
            <Btn size="sm" variant="danger" onClick={() => setResetOpen(true)}><RotateCcw size={14} /> Reset all</Btn>
          </div>
          <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={(e) => { void importData(e.target.files?.[0]); e.target.value = ""; }} />
        </div>

        <div className={cx(PANEL, "space-y-4")}>
          <AdminHead title="Realtime database" sub="Firebase Realtime Database — muhyissunna-ab17e." />
          {dbError ? (
            <>
              <p className="rounded-xl bg-red-500/10 p-3 text-sm font-semibold text-red-500">
                Sync blocked ({dbError}) — the site runs in local mode until rules allow access.
              </p>
              <p className="text-sm tx-soft">Firebase Console → Realtime Database → Rules → publish:</p>
              <pre className="overflow-x-auto rounded-xl bg-black/80 p-4 font-mono text-xs text-emerald-300">{RULES_SNIPPET}</pre>
            </>
          ) : connected ? (
            <p className="rounded-xl bg-emerald-500/10 p-3 text-sm font-semibold text-emerald-600">
              Connected — every change syncs to all visitors in real time.
            </p>
          ) : (
            <p className="rounded-xl bg-amber-500/10 p-3 text-sm font-semibold text-amber-600">Connecting to Firebase…</p>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={resetOpen}
        title="Reset the entire site?"
        message="All publications, media, settings and credentials return to the original defaults. Export a backup first if you need it."
        confirmLabel="Reset everything"
        onCancel={() => setResetOpen(false)}
        onConfirm={resetAll}
      />
    </div>
  );
}
