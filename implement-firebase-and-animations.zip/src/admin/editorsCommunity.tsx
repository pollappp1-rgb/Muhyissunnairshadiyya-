import { useState } from "react";
import { BadgeCheck, Check, ChevronDown, Flag, Pencil, Plus, ScrollText, Send, Trash2, Trophy } from "lucide-react";
import { Avatar, Btn, Chip, ConfirmDialog, Field, FileOrLink, Modal, TextArea, TextInput, Toggle } from "../components/ui";
import { useSite } from "../store";
import { cx, timeAgo, todayISO, uid } from "../utils";
import type { Award, Member } from "../types";
import { ACT, AdminHead, MoveBtns, Row, VisToggle, move, useCrud } from "./shared";

/* ================================================================== */
export function ForumsAdmin() {
  const { items, save } = useCrud("forums");
  const [openId, setOpenId] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const [delId, setDelId] = useState<string | null>(null);
  const sorted = items.slice().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const addReply = (id: string) => {
    if (!reply.trim()) return;
    save(
      items.map((t) =>
        t.id === id
          ? { ...t, responses: [...t.responses, { by: "Admin Team", text: reply.trim(), date: todayISO(), admin: true }] }
          : t
      ),
      "Reply posted — live on the forum now."
    );
    setReply("");
  };

  return (
    <div>
      <AdminHead title="Forums" sub="Student topics and your official replies — everything is realtime." />
      <div className="grid gap-2.5">
        {sorted.map((t) => {
          const open = openId === t.id;
          return (
            <div key={t.id} className={cx("overflow-hidden rounded-2xl bg-[var(--surface)] ring-line", open && "ring-2 ring-[var(--primary)]")}>
              <button onClick={() => setOpenId(open ? null : t.id)} className="flex w-full items-center gap-3 p-4 text-left">
                <Avatar name={t.name} sizeClass="h-10 w-10" textClass="text-xs" />
                <span className="min-w-0 flex-1">
                  <span className="line-clamp-1 font-semibold">{t.subject}</span>
                  <span className="mt-0.5 block text-xs tx-faint">
                    {t.name} · {timeAgo(t.date)} · {t.responses.length} {t.responses.length === 1 ? "reply" : "replies"}
                  </span>
                </span>
                {t.responses.length === 0 && <Chip color="#dc2626">Awaiting reply</Chip>}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    save(items.map((x) => (x.id === t.id ? { ...x, status: x.status === "open" ? "closed" : "open" } : x)), `Topic ${t.status === "open" ? "closed" : "reopened"}`);
                  }}
                  className={cx("rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wider", t.status === "open" ? "bg-emerald-500/10 text-emerald-600" : "bg-black/10 tx-faint")}
                >
                  {t.status === "open" ? "Open" : "Closed"}
                </button>
                <ChevronDown size={16} className={cx("tx-faint transition-transform", open && "rotate-180")} />
              </button>
              {open && (
                <div className="fade-in space-y-4 border-t line p-4">
                  <p className="whitespace-pre-line rounded-xl soft-panel p-4 text-sm leading-relaxed">{t.message}</p>
                  {t.responses.map((r, i) => (
                    <div key={i} className={cx("rounded-xl p-4 text-sm", r.admin ? "bg-[color-mix(in_srgb,var(--primary)_8%,transparent)]" : "soft-panel")}>
                      <div className="mb-1 flex items-center gap-2 text-xs font-bold">
                        {r.admin && <BadgeCheck size={13} className="tx-primary" />}
                        {r.by}
                        <span className="font-normal tx-faint">{timeAgo(r.date)}</span>
                      </div>
                      {r.text}
                    </div>
                  ))}
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <TextArea value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write an official reply…" className="min-h-[70px] flex-1" />
                    <div className="flex items-end gap-2">
                      <Btn size="sm" onClick={() => addReply(t.id)}><Send size={14} /> Reply</Btn>
                      <Btn size="sm" variant="danger" onClick={() => setDelId(t.id)}><Trash2 size={14} /></Btn>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
        {sorted.length === 0 && <p className="py-10 text-center text-sm tx-faint">No forum topics yet — students can post from the Forums page.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this topic?"
        message="The question and all replies are removed."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((t) => t.id !== delId), "Topic deleted");
          setDelId(null);
          setOpenId(null);
        }}
      />
    </div>
  );
}

/* ================================================================== */
function kindColor(k: string): string {
  if (k === "Complaint") return "#dc2626";
  if (k === "Suggestion") return "#0b6b4f";
  if (k === "Feedback") return "#b45309";
  return "#6b7280";
}

export function ComplaintsAdmin() {
  const { items, save } = useCrud("complaints");
  const [delId, setDelId] = useState<string | null>(null);
  const unread = items.filter((c) => !c.read).length;
  const sorted = items
    .slice()
    .sort((a, b) => Number(a.read) - Number(b.read) || new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div>
      <AdminHead
        title="Reports inbox"
        sub="Complaints, suggestions & feedback — each shows the student's name and exact time."
        right={unread > 0 ? <Chip color="#dc2626"><Flag size={11} /> {unread} unread</Chip> : undefined}
      />
      <div className="grid gap-2.5">
        {sorted.map((c) => (
          <div key={c.id} className={cx("rounded-2xl bg-[var(--surface)] p-4 ring-line", !c.read && "border-l-4 border-[var(--accent)]")}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <Avatar name={c.name} sizeClass="h-10 w-10" textClass="text-xs" />
                <div>
                  <div className="font-bold">{c.name}</div>
                  <div className="text-xs tx-faint">
                    {new Date(c.date).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" })}
                  </div>
                </div>
                <Chip color={kindColor(c.kind)}>{c.kind}</Chip>
                {!c.read && <span className="h-2 w-2 rounded-full bg-red-500" title="Unread" />}
              </div>
              <div className="flex gap-1">
                <button
                  type="button"
                  className={ACT}
                  title={c.read ? "Mark unread" : "Mark read"}
                  onClick={() => save(items.map((x) => (x.id === c.id ? { ...x, read: !x.read } : x)))}
                >
                  <Check size={15} className={c.read ? "tx-primary" : "opacity-40"} />
                </button>
                <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={() => setDelId(c.id)}>
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
            <p className="mt-3 whitespace-pre-line rounded-xl soft-panel p-4 text-sm leading-relaxed">{c.message}</p>
          </div>
        ))}
        {sorted.length === 0 && <p className="py-10 text-center text-sm tx-faint">Inbox is empty — reports from the Report page appear here instantly.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this report?"
        message="It is permanently removed from the inbox."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((c) => c.id !== delId), "Report deleted");
          setDelId(null);
        }}
      />
    </div>
  );
}

/* ================================================================== */
export function CommitteeEditor() {
  const { items, save } = useCrud("members");
  const { toast } = useSite();
  const [editing, setEditing] = useState<Member | null>(null);
  const [delId, setDelId] = useState<string | null>(null);

  const blank: Member = { id: "", name: "", role: "", photo: "", bio: "", visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.name.trim() || !editing.role.trim()) {
      toast("Name and role are required.", "error");
      return;
    }
    if (editing.id) save(items.map((m) => (m.id === editing.id ? editing : m)), "Member updated");
    else save([...items, { ...editing, id: uid() }], "Member added");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Committee"
        sub="Association members shown on the homepage and Committee page."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> Add member</Btn>}
      />
      <div className="grid gap-2.5">
        {items.map((m, i) => (
          <Row key={m.id}>
            <MoveBtns index={i} len={items.length} onMove={(d) => save(move(items, i, d))} />
            <Avatar name={m.name} photo={m.photo} sizeClass="h-11 w-11" textClass="text-xs" />
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{m.name}</div>
              <div className="text-xs tx-faint">{m.role}</div>
            </div>
            <VisToggle v={m.visible} onChange={(v) => save(items.map((x) => (x.id === m.id ? { ...x, visible: v } : x)))} />
            <button type="button" className={ACT} onClick={() => setEditing(m)}><Pencil size={15} /></button>
            <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={() => setDelId(m.id)}><Trash2 size={15} /></button>
          </Row>
        ))}
        {items.length === 0 && <p className="py-10 text-center text-sm tx-faint">No members yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Remove this member?"
        message="They disappear from the committee pages."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((m) => m.id !== delId), "Member removed");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit member" : "Add member"}</h3>
            <div className="mt-5 space-y-4">
              <Field label="Full name"><TextInput value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></Field>
              <Field label="Role"><TextInput value={editing.role} onChange={(e) => setEditing({ ...editing, role: e.target.value })} placeholder="President · Secretary · Chief Editor…" /></Field>
              <FileOrLink label="Photo" kind="image" value={editing.photo} onChange={(v) => setEditing({ ...editing, photo: v })} hint="optional · initials shown if empty" />
              <Field label="Short bio"><TextArea value={editing.bio} onChange={(e) => setEditing({ ...editing, bio: e.target.value })} className="min-h-[80px]" /></Field>
              <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible on site" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save member</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================================================================== */
export function AwardsEditor() {
  const { items, save } = useCrud("awards");
  const { toast } = useSite();
  const [tab, setTab] = useState<"achievement" | "result">("achievement");
  const [editing, setEditing] = useState<Award | null>(null);
  const [delId, setDelId] = useState<string | null>(null);
  const list = items.filter((a) => a.kind === tab);

  const blank: Award = { id: "", kind: tab, title: "", name: "", detail: "", year: new Date().getFullYear().toString(), image: "", visible: true };

  const commit = () => {
    if (!editing) return;
    if (!editing.title.trim()) {
      toast("Title is required.", "error");
      return;
    }
    if (editing.id) save(items.map((a) => (a.id === editing.id ? editing : a)), "Entry updated");
    else save([...items, { ...editing, id: uid() }], "Entry added");
    setEditing(null);
  };

  return (
    <div>
      <AdminHead
        title="Achievements & Results"
        sub="Student prizes and official program results."
        right={<Btn size="sm" onClick={() => setEditing(blank)}><Plus size={15} /> Add entry</Btn>}
      />
      <div className="mb-5 inline-flex rounded-full border line bg-[var(--surface)] p-1">
        {(["achievement", "result"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={cx("flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold uppercase tracking-widest transition", tab === k ? "bg-primary tx-on" : "tx-soft")}
          >
            {k === "achievement" ? <Trophy size={13} /> : <ScrollText size={13} />}
            {k === "achievement" ? "Achievements" : "Results"}
          </button>
        ))}
      </div>
      <div className="grid gap-2.5">
        {list.map((a) => (
          <Row key={a.id}>
            <span className={cx("flex h-11 w-11 shrink-0 items-center justify-center rounded-xl", a.kind === "achievement" ? "bg-[color-mix(in_srgb,var(--accent)_18%,transparent)] tx-accent" : "soft-panel tx-faint")}>
              {a.kind === "achievement" ? <Trophy size={17} /> : <ScrollText size={17} />}
            </span>
            <div className="min-w-0 flex-1">
              <div className="truncate font-semibold">{a.title}</div>
              <div className="truncate text-xs tx-faint">{a.name} · {a.year}</div>
            </div>
            <VisToggle v={a.visible} onChange={(v) => save(items.map((x) => (x.id === a.id ? { ...x, visible: v } : x)))} />
            <button type="button" className={ACT} onClick={() => setEditing(a)}><Pencil size={15} /></button>
            <button type="button" className={cx(ACT, "text-red-500 hover:bg-red-50")} onClick={() => setDelId(a.id)}><Trash2 size={15} /></button>
          </Row>
        ))}
        {list.length === 0 && <p className="py-10 text-center text-sm tx-faint">No {tab === "achievement" ? "achievements" : "results"} yet.</p>}
      </div>

      <ConfirmDialog
        open={!!delId}
        title="Delete this entry?"
        message="It is removed from the Hall of Fame."
        onCancel={() => setDelId(null)}
        onConfirm={() => {
          save(items.filter((a) => a.id !== delId), "Entry deleted");
          setDelId(null);
        }}
      />

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <div>
            <h3 className="font-display text-xl font-bold">{editing.id ? "Edit entry" : `New ${editing.kind === "achievement" ? "achievement" : "result"}`}</h3>
            <div className="mt-5 space-y-4">
              <Field label="Title"><TextInput value={editing.title} onChange={(e) => setEditing({ ...editing, title: e.target.value })} placeholder={editing.kind === "achievement" ? "First Prize — District Elocution" : "Muhyissunna Fest 2026 — Results"} /></Field>
              <Field label={editing.kind === "achievement" ? "Student name" : "Winners / summary"}>
                <TextInput value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Year"><TextInput value={editing.year} onChange={(e) => setEditing({ ...editing, year: e.target.value })} /></Field>
                <div className="flex items-end pb-1">
                  <Toggle checked={editing.visible} onChange={(v) => setEditing({ ...editing, visible: v })} label="Visible" />
                </div>
              </div>
              <Field label="Details"><TextArea value={editing.detail} onChange={(e) => setEditing({ ...editing, detail: e.target.value })} className="min-h-[80px]" /></Field>
              <FileOrLink label="Photo" kind="image" value={editing.image} onChange={(v) => setEditing({ ...editing, image: v })} hint="optional · upload or link" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn onClick={commit}>Save entry</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
