import type { ReactNode } from "react";
import { ChevronDown, ChevronUp, Eye, EyeOff } from "lucide-react";
import { useSite } from "../store";
import { cx } from "../utils";
import type { SiteData } from "../types";

export type ArrayKey = { [K in keyof SiteData]: SiteData[K] extends unknown[] ? K : never }[keyof SiteData];

export function useCrud<K extends ArrayKey>(key: K) {
  const { data, setSection, toast } = useSite();
  const items = data[key];
  const save = (next: SiteData[K], msg?: string) => {
    setSection(key, next, true);
    if (msg) toast(msg);
  };
  return { items, save, toast };
}

export const PANEL = "rounded-[1.8rem] bg-[var(--surface)] p-5 ring-line sm:p-7";
export const ACT = "rounded-full p-2 transition hover:soft-panel tx-soft";

export function AdminHead({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight sm:text-[1.9rem]">{title}</h1>
        {sub && <p className="mt-1 text-sm tx-faint">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function Row({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={cx("flex items-center gap-3 rounded-2xl bg-[var(--surface)] p-3 ring-line", className)}>{children}</div>;
}

export function VisToggle({ v, onChange, title }: { v: boolean; onChange: (x: boolean) => void; title?: string }) {
  return (
    <button type="button" title={title || (v ? "Hide" : "Show")} onClick={() => onChange(!v)} className={ACT}>
      {v ? <Eye size={15} className="tx-primary" /> : <EyeOff size={15} className="opacity-50" />}
    </button>
  );
}

export function move<T>(arr: T[], i: number, dir: -1 | 1): T[] {
  const j = i + dir;
  if (j < 0 || j >= arr.length) return arr;
  const next = arr.slice();
  const [x] = next.splice(i, 1);
  next.splice(j, 0, x);
  return next;
}

export function MoveBtns({ index, len, onMove }: { index: number; len: number; onMove: (dir: -1 | 1) => void }) {
  return (
    <span className="flex flex-col">
      <button type="button" disabled={index === 0} onClick={() => onMove(-1)} className="p-0.5 disabled:opacity-25" title="Move up">
        <ChevronUp size={14} />
      </button>
      <button type="button" disabled={index === len - 1} onClick={() => onMove(1)} className="p-0.5 disabled:opacity-25" title="Move down">
        <ChevronDown size={14} />
      </button>
    </span>
  );
}
