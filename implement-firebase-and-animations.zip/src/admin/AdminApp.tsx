import { useState } from "react";
import {
  ArrowUpRight, CalendarDays, Clapperboard, Flag, Globe, Images, LayoutDashboard, LayoutGrid, LockKeyhole,
  LogOut, Megaphone, Menu, MessagesSquare, Newspaper, Palette, PanelTop, PenLine, Settings, ShieldCheck,
  Tags, Trophy, Users, Wifi, WifiOff, X,
} from "lucide-react";
import { Brand } from "../components/Chrome";
import { Btn } from "../components/ui";
import { useSite } from "../store";
import { cx } from "../utils";
import { PANEL } from "./shared";
import { CategoriesEditor, EventsEditor, GalleryEditor, MagazinesEditor, PublicationsEditor, VideosEditor } from "./editorsContent";
import { AwardsEditor, CommitteeEditor, ComplaintsAdmin, ForumsAdmin } from "./editorsCommunity";
import { AnnounceEditor, LayoutEditor, PopupEditor, SettingsEditor, ThemeEditor } from "./editorsSite";

type IconC = React.ComponentType<{ size?: number | string; className?: string }>;

const GROUPS: { label: string; items: { id: string; label: string; icon: IconC }[] }[] = [
  { label: "Overview", items: [{ id: "dash", label: "Dashboard", icon: LayoutDashboard }] },
  {
    label: "Content",
    items: [
      { id: "pubs", label: "Publications", icon: PenLine },
      { id: "cats", label: "Categories", icon: Tags },
      { id: "mags", label: "Magazines", icon: Newspaper },
      { id: "gallery", label: "Photo Gallery", icon: Images },
      { id: "videos", label: "Videos", icon: Clapperboard },
      { id: "events", label: "Events", icon: CalendarDays },
    ],
  },
  {
    label: "Community",
    items: [
      { id: "forums", label: "Forums", icon: MessagesSquare },
      { id: "complaints", label: "Reports", icon: Flag },
      { id: "committee", label: "Committee", icon: Users },
      { id: "awards", label: "Awards & Results", icon: Trophy },
    ],
  },
  {
    label: "Site Studio",
    items: [
      { id: "layout", label: "Home & Buttons", icon: LayoutGrid },
      { id: "announce", label: "Ticker & Notices", icon: Megaphone },
      { id: "popup", label: "Popup Alert", icon: PanelTop },
      { id: "theme", label: "Theme & Branding", icon: Palette },
      { id: "settings", label: "Settings & Data", icon: Settings },
    ],
  },
];

function moduleTitle(mod: string): string {
  for (const g of GROUPS) for (const it of g.items) if (it.id === mod) return it.label;
  return "Dashboard";
}

/* ================================================================== */
function Login() {
  const { login, nav, toast } = useSite();
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState(false);

  const submit = () => {
    if (login(u, p)) {
      toast("Assalamu alaikum — welcome back, admin.");
    } else {
      setErr(true);
      window.setTimeout(() => setErr(false), 600);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-16">
      <div className={cx("w-full max-w-sm rounded-[2rem] bg-[var(--surface)] p-8 shadow-2xl ring-line", err && "shake")}>
        <div className="flex justify-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary tx-on shadow-lg">
            <ShieldCheck size={30} />
          </span>
        </div>
        <h1 className="mt-5 text-center font-display text-2xl font-bold">Admin Portal</h1>
        <p className="mt-1 text-center text-sm tx-faint">Restricted to the association admin team.</p>
        <div className="mt-7 space-y-4">
          <div className="relative">
            <Users size={15} className="absolute left-4 top-1/2 -translate-y-1/2 tx-faint" />
            <input
              value={u}
              onChange={(e) => setU(e.target.value)}
              placeholder="Username"
              autoComplete="username"
              className="w-full rounded-xl border line bg-transparent py-3 pl-11 pr-4 text-sm outline-none focus:border-[var(--primary)]"
            />
          </div>
          <div className="relative">
            <LockKeyhole size={15} className="absolute left-4 top-1/2 -translate-y-1/2 tx-faint" />
            <input
              type="password"
              value={p}
              onChange={(e) => setP(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              placeholder="Password"
              autoComplete="current-password"
              className="w-full rounded-xl border line bg-transparent py-3 pl-11 pr-4 text-sm outline-none focus:border-[var(--primary)]"
            />
          </div>
          {err && <p className="fade-in text-center text-sm font-semibold text-red-500">Incorrect username or password.</p>}
          <Btn className="w-full" onClick={submit}>Enter portal</Btn>
          <button onClick={() => nav("home")} className="mx-auto block text-xs font-bold uppercase tracking-widest tx-faint hover:tx-soft">
            ← Back to site
          </button>
        </div>
      </div>
    </main>
  );
}

/* ================================================================== */
function ConnPill() {
  const { connected, dbError } = useSite();
  if (dbError)
    return (
      <span className="flex items-center gap-2 rounded-full bg-red-500/10 px-3.5 py-2 text-[11px] font-bold uppercase tracking-widest text-red-500">
        <WifiOff size={13} /> Local mode
      </span>
    );
  if (connected)
    return (
      <span className="flex items-center gap-2 rounded-full bg-emerald-500/10 px-3.5 py-2 text-[11px] font-bold uppercase tracking-widest text-emerald-500">
        <span className="relative flex h-2 w-2 rounded-full bg-emerald-500"><span className="pulse-dot text-emerald-500" /></span>
        <Wifi size={13} /> Live sync
      </span>
    );
  return (
    <span className="rounded-full bg-amber-500/10 px-3.5 py-2 text-[11px] font-bold uppercase tracking-widest text-amber-500">Syncing…</span>
  );
}

const RULES_SNIPPET = `{
  "rules": {
    ".read": true,
    ".write": true
  }
}`;

/* ================================================================== */
function Dashboard({ go }: { go: (m: string) => void }) {
  const { data, dbError } = useSite();
  const unread = data.complaints.filter((c) => !c.read).length;
  const openTopics = data.forums.filter((f) => f.status === "open" && f.responses.length === 0).length;
  const stats: { label: string; value: number; icon: IconC; mod: string }[] = [
    { label: "Publications", value: data.publications.length, icon: PenLine, mod: "pubs" },
    { label: "Magazines", value: data.magazines.length, icon: Newspaper, mod: "mags" },
    { label: "Albums", value: data.albums.length, icon: Images, mod: "gallery" },
    { label: "Videos", value: data.videos.length, icon: Clapperboard, mod: "videos" },
    { label: "Events", value: data.events.length, icon: CalendarDays, mod: "events" },
    { label: "Notices", value: data.notices.length, icon: Megaphone, mod: "announce" },
    { label: "Awards", value: data.awards.length, icon: Trophy, mod: "awards" },
    { label: "Committee", value: data.members.length, icon: Users, mod: "committee" },
    { label: "Forum topics", value: data.forums.length, icon: MessagesSquare, mod: "forums" },
    { label: "Reports", value: data.complaints.length, icon: Flag, mod: "complaints" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">Assalamu alaikum, admin</h1>
      <p className="mt-1 text-sm tx-faint">
        {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })} — everything you
        publish here goes live on the site instantly.
      </p>

      {dbError && (
        <div className="mt-6 rounded-2xl border border-red-300/60 bg-red-500/5 p-5">
          <p className="text-sm font-bold text-red-500">Firebase is blocking realtime sync ({dbError}).</p>
          <p className="mt-1 text-sm tx-soft">
            The site works in local mode meanwhile. To enable realtime sync, open Firebase Console → Realtime Database → Rules and publish:
          </p>
          <pre className="mt-3 overflow-x-auto rounded-xl bg-black/80 p-4 font-mono text-xs text-emerald-300">{RULES_SNIPPET}</pre>
        </div>
      )}

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-5">
        {stats.map((s) => (
          <button
            key={s.label}
            onClick={() => go(s.mod)}
            className={cx(PANEL, "card-lift group p-5 text-left")}
          >
            <s.icon size={18} className="tx-primary transition-transform duration-300 group-hover:scale-110" />
            <div className="mt-3 font-display text-3xl font-bold">{s.value}</div>
            <div className="mt-0.5 text-[11px] font-bold uppercase tracking-[0.16em] tx-faint">{s.label}</div>
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <button onClick={() => go("complaints")} className={cx(PANEL, "card-lift flex items-center gap-4 text-left")}>
          <span className={cx("flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl", unread > 0 ? "bg-red-500/10 text-red-500" : "soft-panel tx-faint")}>
            <Flag size={22} />
          </span>
          <span className="flex-1">
            <span className="block font-display text-lg font-bold">
              {unread > 0 ? `${unread} unread report${unread > 1 ? "s" : ""}` : "No pending reports"}
            </span>
            <span className="mt-0.5 block text-sm tx-faint">
              {unread > 0 ? "Students are waiting — review and mark them read." : "Complaints & suggestions inbox is clear."}
            </span>
          </span>
          <ArrowUpRight size={18} className="tx-faint" />
        </button>
        <button onClick={() => go("forums")} className={cx(PANEL, "card-lift flex items-center gap-4 text-left")}>
          <span className={cx("flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl", openTopics > 0 ? "bg-[color-mix(in_srgb,var(--accent)_18%,transparent)] tx-accent" : "soft-panel tx-faint")}>
            <MessagesSquare size={22} />
          </span>
          <span className="flex-1">
            <span className="block font-display text-lg font-bold">
              {openTopics > 0 ? `${openTopics} topic${openTopics > 1 ? "s" : ""} awaiting reply` : "Forums are answered"}
            </span>
            <span className="mt-0.5 block text-sm tx-faint">Reply publicly as the association.</span>
          </span>
          <ArrowUpRight size={18} className="tx-faint" />
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
export default function AdminApp() {
  const { isAdmin, logout, nav, data } = useSite();
  const [mod, setMod] = useState("dash");
  const [drawer, setDrawer] = useState(false);
  const unread = data.complaints.filter((c) => !c.read).length;

  if (!isAdmin) return <Login />;

  const go = (m: string) => {
    setMod(m);
    setDrawer(false);
    window.scrollTo({ top: 0 });
  };

  const SidebarBody = (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-5 pb-5 pt-5">
        <Brand />
        <button className="rounded-full border line p-2 lg:hidden" onClick={() => setDrawer(false)} aria-label="Close">
          <X size={15} />
        </button>
      </div>
      <div className="px-5 pb-4">
        <span className="rounded-full bg-primary/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] tx-primary">Admin Portal</span>
      </div>
      <nav className="flex-1 space-y-5 overflow-y-auto px-4 pb-6 no-scrollbar">
        {GROUPS.map((g) => (
          <div key={g.label}>
            <div className="px-2 pb-2 text-[10px] font-bold uppercase tracking-[0.28em] tx-faint">{g.label}</div>
            <div className="space-y-1">
              {g.items.map((it) => (
                <button
                  key={it.id}
                  onClick={() => go(it.id)}
                  className={cx(
                    "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition",
                    mod === it.id ? "bg-primary tx-on shadow-md" : "tx-soft hover:soft-panel hover:tx"
                  )}
                >
                  <it.icon size={16} />
                  {it.label}
                  {it.id === "complaints" && unread > 0 && (
                    <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-[10px] font-bold text-white">
                      {unread}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>
      <div className="space-y-2 border-t line p-4">
        <ConnPill />
        <div className="flex gap-2">
          <button
            onClick={() => nav("home")}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border line py-2.5 text-xs font-bold uppercase tracking-widest tx-soft transition hover:tx-primary"
          >
            <Globe size={13} /> View site
          </button>
          <button
            onClick={logout}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-red-500/10 py-2.5 text-xs font-bold uppercase tracking-widest text-red-500 transition hover:bg-red-500/20"
          >
            <LogOut size={13} /> Logout
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[290px_1fr]">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[290px] border-r line bg-[var(--bg)] lg:block">{SidebarBody}</aside>
      {drawer && (
        <div className="fixed inset-0 z-[80] lg:hidden">
          <div className="fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setDrawer(false)} />
          <aside className="pop-in absolute left-0 top-0 h-full w-[86%] max-w-xs bg-[var(--bg)] shadow-2xl">{SidebarBody}</aside>
        </div>
      )}
      <div className="lg:col-start-2">
        <div className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b line bg-[color-mix(in_srgb,var(--bg)_85%,transparent)] px-4 py-3 backdrop-blur-xl sm:px-8">
          <div className="flex items-center gap-3">
            <button className="rounded-full border line p-2 lg:hidden" onClick={() => setDrawer(true)} aria-label="Menu">
              <Menu size={16} />
            </button>
            <span className="font-display text-lg font-bold">{moduleTitle(mod)}</span>
          </div>
          <div className="hidden sm:block"><ConnPill /></div>
        </div>
        <div className="px-4 py-8 sm:px-8">
          {mod === "dash" && <Dashboard go={go} />}
          {mod === "pubs" && <PublicationsEditor />}
          {mod === "cats" && <CategoriesEditor />}
          {mod === "mags" && <MagazinesEditor />}
          {mod === "gallery" && <GalleryEditor />}
          {mod === "videos" && <VideosEditor />}
          {mod === "events" && <EventsEditor />}
          {mod === "forums" && <ForumsAdmin />}
          {mod === "complaints" && <ComplaintsAdmin />}
          {mod === "committee" && <CommitteeEditor />}
          {mod === "awards" && <AwardsEditor />}
          {mod === "layout" && <LayoutEditor />}
          {mod === "announce" && <AnnounceEditor />}
          {mod === "popup" && <PopupEditor />}
          {mod === "theme" && <ThemeEditor />}
          {mod === "settings" && <SettingsEditor />}
        </div>
      </div>
    </div>
  );
}
