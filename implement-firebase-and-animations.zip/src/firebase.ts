// Firebase initialization — MUHYISSUNNA KOLATHUR
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyDhrka1O-hEjHldqnFK_eTT5RRi4h0OQRg",
  authDomain: "muhyissunna-ab17e.firebaseapp.com",
  databaseURL: "https://muhyissunna-ab17e-default-rtdb.firebaseio.com",
  projectId: "muhyissunna-ab17e",
  storageBucket: "muhyissunna-ab17e.firebasestorage.app",
  messagingSenderId: "236230556265",
  appId: "1:236230556265:web:785958cfa65ca5e75000f8",
  measurementId: "G-CDYXH4BZJ3",
};

export const firebaseApp = initializeApp(firebaseConfig);

try {
  getAnalytics(firebaseApp);
} catch {
  /* analytics is not available in this environment — safe to ignore */
}

export const db = getDatabase(firebaseApp);
