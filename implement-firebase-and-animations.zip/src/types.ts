export interface Theme {
  bg: string;
  surface: string;
  ink: string;
  primary: string;
  onPrimary: string;
  accent: string;
  tickerBg: string;
  tickerText: string;
}

export interface PopupCfg {
  enabled: boolean;
  title: string;
  message: string;
  image: string;
  buttonText: string;
  buttonTarget: string;
  showOnce: boolean;
}

export interface TickerItem {
  id: string;
  text: string;
  visible: boolean;
}

export interface TickerCfg {
  enabled: boolean;
  direction: "rtl" | "ltr";
  speed: "slow" | "normal" | "fast";
  items: TickerItem[];
}

export interface AuthCfg {
  username: string;
  password: string;
}

export interface SiteSettings {
  siteName: string;
  siteUnit: string;
  tagline: string;
  logo: string;
  heroBadge: string;
  heroTitle: string;
  heroAccent: string;
  heroSubtitle: string;
  heroTitleSize: "compact" | "classic" | "grand" | "massive";
  heroTitleFont: "display" | "sans" | "ar";
  heroTitleColor: string;
  heroAccentColor: string;
  heroImage: string;
  showHeroImage: boolean;
  showLogo: boolean;
  about: string;
  vision: string;
  mission: string;
  footerText: string;
  email: string;
  phone: string;
  address: string;
  theme: Theme;
  popup: PopupCfg;
  ticker: TickerCfg;
  auth: AuthCfg;
}

export interface HomeSection {
  id: string;
  label: string;
  visible: boolean;
}

export interface HomeButton {
  id: string;
  label: string;
  icon: string;
  target: string;
  visible: boolean;
}

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface Publication {
  id: string;
  title: string;
  author: string;
  category: string;
  excerpt: string;
  content: string;
  thumbnail: string;
  date: string;
  likes: number;
  featured: boolean;
  visible: boolean;
}

export interface Magazine {
  id: string;
  title: string;
  issue: string;
  date: string;
  description: string;
  cover: string;
  pdf: string;
  downloads: number;
  visible: boolean;
}

export interface Album {
  id: string;
  title: string;
  date: string;
  cover: string;
  images: string[];
  visible: boolean;
}

export interface VideoItem {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  category: string;
  date: string;
  views: number;
  visible: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  description: string;
  poster: string;
  visible: boolean;
}

export interface Notice {
  id: string;
  text: string;
  link: string;
  important: boolean;
  date: string;
  visible: boolean;
}

export interface Award {
  id: string;
  kind: "achievement" | "result";
  title: string;
  name: string;
  detail: string;
  year: string;
  image: string;
  visible: boolean;
}

export interface Member {
  id: string;
  name: string;
  role: string;
  photo: string;
  bio: string;
  visible: boolean;
}

export interface ForumResp {
  by: string;
  text: string;
  date: string;
  admin: boolean;
}

export interface ForumTopic {
  id: string;
  name: string;
  subject: string;
  message: string;
  date: string;
  status: "open" | "closed";
  responses: ForumResp[];
}

export interface Complaint {
  id: string;
  name: string;
  kind: string;
  message: string;
  date: string;
  read: boolean;
}

export interface SiteData {
  settings: SiteSettings;
  homeLayout: HomeSection[];
  homeButtons: HomeButton[];
  categories: Category[];
  publications: Publication[];
  magazines: Magazine[];
  albums: Album[];
  videos: VideoItem[];
  events: EventItem[];
  notices: Notice[];
  awards: Award[];
  members: Member[];
  forums: ForumTopic[];
  complaints: Complaint[];
}

export type PageKey =
  | "home"
  | "works"
  | "magazines"
  | "gallery"
  | "videos"
  | "events"
  | "notices"
  | "awards"
  | "committee"
  | "forums"
  | "report"
  | "about"
  | "admin";

export interface Route {
  page: PageKey;
  id?: string;
}
