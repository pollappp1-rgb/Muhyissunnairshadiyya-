import { useEffect, useState } from "react";
import {
  AlertTriangle, ArrowUpRight, Bell, BookOpen, CalendarDays, CheckCircle2, Clapperboard, Flag, Home,
  Images, Info, Mail, MapPin, Menu, MessagesSquare, Newspaper, Phone, Shield, Sparkles, Trophy, Users, X,
} from "lucide-react";
import { useSite } from "../store";
import { cx } from "../utils";
import type { PageKey, Route } from "../types";

const LINKS: { page: PageKey; label: string; icon: typeof Home }[] = [
  { page: "home", label: "Home", icon: Home },
  { page: "works", label: "Publications", icon: BookOpen },
  { page: "magazines", label: "Magazines", icon: Newspaper },
  { page: "gallery", label: "Gallery", icon: Images },
  { page: "videos", label: "Videos", icon: Clapperboard },
  { page: "events", label: "Events", icon: CalendarDays },
  { page: "notices", label: "Notices", icon: Bell },
  { page: "awards", label: "Awards", icon: Trophy },
  { page: "committee", label: "Committee", icon: Users },
  { page: "forums", label: "Forums", icon: MessagesSquare },
  { page: "report", label: "Report", icon: Flag },
  { page: "about", label: "About", icon: Info },
];

const TOP_LINKS: PageKey[] = ["home", "works", "magazines", "gallery", "videos", "events"];

/* ------------------------------------------------------------------ */
/* Notification ticker — starts on page load, right-to-left by default */
/* ------------------------------------------------------------------ */
export function Ticker() {
  const { data } = useSite();
  const t = data.settings.ticker;
  const visibleItems = t.items.filter((i) => i.visible && i.text.trim());
  if (!t.enabled || visibleItems.length === 0) return null;
  const speeds = { slow: 46, normal: 28, fast: 15 } as const;
  const rep = Math.max(2, Math.ceil(10 / visibleItems.length));
  const chunk = Array.from({ length: rep }).flatMap(() => visibleItems);
  return (
    <div className="relative overflow-hidden" style={{ background: "var(--ticker-bg)", color: "var(--ticker-text)" }}>
      <div className="flex items-center">
        <span className="z-10 flex shrink-0 items-center gap-1.5 self-stretch bg-[var(--accent)] px-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[var(--ink)] sm:px-4">
          <MegaphoneIcon /> <span className="hidden sm:inline">News</span>
        </span>
        <div className="flex-1 overflow-hidden py-2" dir="ltr">
          <div
            className="marquee"
            style={{ animationDuration: `${speeds[t.speed]}s`, animationDirection: t.direction === "ltr" ? "reverse" : "normal" }}
          >
            {[0, 1].map((k) => (
              <div className="marquee-chunk" key={k}>
                {chunk.map((item, i) => (
                  <span key={`${item.id}-${i}`} className="inline-flex items-center gap-2.5 whitespace-nowrap px-5 text-xs font-medium tracking-wide">
                    <Sparkles size={11} className="shrink-0 opacity-80" />
                    {item.text}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MegaphoneIcon() {
  return <Bell size={11} strokeWidth={2.5} />;
}

/* ------------------------------------------------------------------ */
/* Brand lockup                                                        */
/* ------------------------------------------------------------------ */
export function Brand({ compact = false }: { compact?: boolean }) {
  const { data } = useSite();
  const s = data.settings;
  return (
    <div className="flex items-center gap-3">
      {s.logo && s.showLogo ? (
        <img src={s.logo} alt="logo" className="h-10 w-10 rounded-xl object-cover shadow-md ring-1 ring-black/5" />
      ) : (
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary font-display text-lg font-bold tx-on shadow-md">
          {(s.siteName || "M").charAt(0)}
        </span>
      )}
      {!compact && (
        <div className="leading-none">
          <div className="font-display text-[15px] font-bold tracking-[0.08em]">{s.siteName}</div>
          <div className="mt-1 text-[9px] font-bold uppercase tracking-[0.42em] tx-accent">{s.siteUnit}</div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Header + mobile drawer                                              */
/* ------------------------------------------------------------------ */
export function Header() {
  const { route, nav } = useSite();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [route]);

  return (
    <>
      <header className="sticky top-0 z-50">
        <Ticker />
        <div className="border-b line bg-[color-mix(in_srgb,var(--bg)_82%,transparent)] backdrop-blur-xl">
          <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
            <button onClick={() => nav("home")} aria-label="Home">
              <Brand />
            </button>
            <nav className="hidden items-center gap-1 lg:flex">
              {LINKS.filter((l) => TOP_LINKS.includes(l.page)).map((l) => (
                <button
                  key={l.page}
                  onClick={() => nav(l.page)}
                  className={cx(
                    "relative rounded-full px-4 py-2 text-[13px] font-semibold transition-colors",
                    route.page === l.page ? "tx-primary" : "tx-soft hover:tx"
                  )}
                >
                  {l.label}
                  {route.page === l.page && <span className="absolute inset-x-4 -bottom-[13px] h-[3px] rounded-full bg-[var(--primary)]" />}
                </button>
              ))}
              <button
                onClick={() => setOpen(true)}
                className={cx(
                  "rounded-full px-4 py-2 text-[13px] font-semibold transition-colors",
                  LINKS.some((l) => l.page === route.page) && !TOP_LINKS.includes(route.page) ? "tx-primary" : "tx-soft hover:tx"
                )}
              >
                More
              </button>
            </nav>
            <div className="flex items-center gap-2">
              <button
                onClick={() => nav("admin")}
                className="hidden items-center gap-2 rounded-full border line px-4 py-2 text-xs font-bold uppercase tracking-widest tx-soft transition hover:tx-primary hover:border-[var(--primary)] sm:flex"
              >
                <Shield size={13} /> Admin
              </button>
              <button onClick={() => setOpen(true)} className="rounded-full border line p-2.5 lg:hidden" aria-label="Menu">
                <Menu size={18} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* drawer */}
      {open && (
        <div className="fixed inset-0 z-[95]">
          <div className="fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <aside className="pop-in absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col bg-[var(--bg)] p-6 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <Brand />
              <button onClick={() => setOpen(false)} className="rounded-full border line p-2" aria-label="Close menu">
                <X size={16} />
              </button>
            </div>
            <nav className="grid flex-1 content-start gap-1 overflow-y-auto no-scrollbar">
              {LINKS.map((l, i) => (
                <button
                  key={l.page}
                  onClick={() => nav(l.page)}
                  className={cx(
                    "flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-semibold transition",
                    route.page === l.page ? "bg-primary tx-on" : "hover:soft-panel tx-soft"
                  )}
                  style={{ animationDelay: `${i * 30}ms` }}
                >
                  <l.icon size={17} />
                  {l.label}
                  <ArrowUpRight size={14} className="ml-auto opacity-60" />
                </button>
              ))}
            </nav>
            <button
              onClick={() => nav("admin")}
              className="mt-4 flex items-center justify-center gap-2 rounded-2xl bg-ink py-3.5 text-sm font-bold uppercase tracking-widest text-[var(--bg)]"
            >
              <Shield size={15} /> Admin Portal
            </button>
          </aside>
        </div>
      )}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Mobile bottom tab bar                                               */
/* ------------------------------------------------------------------ */
export function BottomTab() {
  const { route, nav } = useSite();
  const tabs: { page: PageKey; label: string; icon: typeof Home }[] = [
    { page: "home", label: "Home", icon: Home },
    { page: "works", label: "Works", icon: BookOpen },
    { page: "gallery", label: "Gallery", icon: Images },
    { page: "forums", label: "Forums", icon: MessagesSquare },
    { page: "admin", label: "Admin", icon: Shield },
  ];
  return (
    <nav className="fixed inset-x-3 bottom-3 z-50 grid grid-cols-5 rounded-full bg-[color-mix(in_srgb,var(--ink)_94%,black)] p-1.5 shadow-2xl shadow-black/30 backdrop-blur md:hidden">
      {tabs.map((t) => (
        <button
          key={t.page}
          onClick={() => nav(t.page)}
          className={cx(
            "flex flex-col items-center gap-1 rounded-full py-2 text-[10px] font-bold uppercase tracking-wide transition-all",
            route.page === t.page ? "bg-white/14 text-white" : "text-white/55"
          )}
        >
          <t.icon size={17} />
          {t.label}
        </button>
      ))}
    </nav>
  );
}

/* ------------------------------------------------------------------ */
/* Footer                                                              */
/* ------------------------------------------------------------------ */
export function Footer() {
  const { data, nav } = useSite();
  const s = data.settings;
  return (
    <footer className="relative mt-28 overflow-hidden rounded-t-[2.5rem] bg-ink pb-24 text-[color-mix(in_srgb,var(--bg)_82%,white)] md:pb-10">
      <div className="grain pointer-events-none absolute inset-0" />
      <div className="mx-auto max-w-7xl px-4 pt-14 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <div className="font-display text-4xl font-bold tracking-wide text-[var(--bg)] sm:text-5xl">
              {s.siteName} <span className="tx-accent">{s.siteUnit}</span>
            </div>
            <p className="mt-3 max-w-sm text-sm leading-relaxed opacity-80">{s.footerText}</p>
            <div className="mt-6 space-y-2.5 text-sm opacity-90">
              {s.email && (
                <a href={`mailto:${s.email}`} className="flex items-center gap-3 hover:tx-accent"><Mail size={15} /> {s.email}</a>
              )}
              {s.phone && (
                <a href={`tel:${s.phone}`} className="flex items-center gap-3 hover:tx-accent"><Phone size={15} /> {s.phone}</a>
              )}
              {s.address && (
                <p className="flex items-start gap-3"><MapPin size={15} className="mt-0.5 shrink-0" /> {s.address}</p>
              )}
            </div>
          </div>
          <div>
            <h4 className="mb-4 text-xs font-bold uppercase tracking-[0.3em] tx-accent">Explore</h4>
            <ul className="space-y-2.5 text-sm">
              {(["works", "magazines", "gallery", "videos", "events", "awards"] as PageKey[]).map((p) => (
                <li key={p}>
                  <button onClick={() => nav(p)} className="capitalize opacity-80 transition hover:tx-accent hover:opacity-100">
                    {LINKS.find((l) => l.page === p)?.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mb-4 text-xs font-bold uppercase tracking-[0.3em] tx-accent">Community</h4>
            <ul className="space-y-2.5 text-sm">
              {(["committee", "forums", "notices", "report", "about"] as PageKey[]).map((p) => (
                <li key={p}>
                  <button onClick={() => nav(p)} className="capitalize opacity-80 transition hover:tx-accent hover:opacity-100">
                    {LINKS.find((l) => l.page === p)?.label}
                  </button>
                </li>
              ))}
              <li>
                <button onClick={() => nav("admin")} className="flex items-center gap-1.5 opacity-80 transition hover:tx-accent hover:opacity-100">
                  <Shield size={13} /> Admin Portal
                </button>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-white/10 pt-6 text-center text-xs opacity-70 sm:text-left">
          © {new Date().getFullYear()} {s.siteName} {s.siteUnit} · {s.tagline}
        </div>
      </div>
    </footer>
  );
}

/* ------------------------------------------------------------------ */
/* Admin-controlled popup alert (with optional image)                  */
/* ------------------------------------------------------------------ */
export function PopupAlert() {
  const { data, route, nav } = useSite();
  const cfg = data.settings.popup;
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!cfg.enabled) return;
    if (route.page === "admin") return;
    if (cfg.showOnce && sessionStorage.getItem("muhy-popup-seen") === "1") return;
    const t = window.setTimeout(() => setShow(true), 900);
    return () => window.clearTimeout(t);
  }, [cfg.enabled, cfg.showOnce, route.page]);

  if (!show) return null;
  const close = () => {
    sessionStorage.setItem("muhy-popup-seen", "1");
    setShow(false);
  };

  return (
    <div className="fixed inset-0 z-[96] flex items-center justify-center p-5">
      <div className="fade-in absolute inset-0 bg-black/55 backdrop-blur-sm" onClick={close} />
      <div className="pop-in relative w-full max-w-sm overflow-hidden rounded-[2rem] bg-[var(--surface)] shadow-2xl">
        {cfg.image && <img src={cfg.image} alt="" className="h-44 w-full object-cover" />}
        <button onClick={close} className="absolute right-3.5 top-3.5 rounded-full bg-black/45 p-2 text-white hover:bg-black/70" aria-label="Close">
          <X size={14} />
        </button>
        <div className="p-6 text-center">
          <span className="tx-accent"><Sparkles size={18} className="mx-auto" /></span>
          <h3 className="mt-2 font-display text-xl font-bold leading-snug">{cfg.title}</h3>
          <p className="mt-2 text-sm leading-relaxed tx-soft">{cfg.message}</p>
          <div className="mt-5 flex flex-col gap-2">
            {cfg.buttonText && (
              <button
                onClick={() => {
                  close();
                  nav((cfg.buttonTarget || "home") as Route["page"]);
                }}
                className="w-full rounded-full bg-primary py-3 text-sm font-bold tx-on transition hover:-translate-y-0.5 hover:shadow-lg"
              >
                {cfg.buttonText}
              </button>
            )}
            <button onClick={close} className="text-xs font-semibold uppercase tracking-widest tx-faint hover:tx-soft">
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Toast popups                                                        */
/* ------------------------------------------------------------------ */
export function Toasts() {
  const { toasts, dismissToast } = useSite();
  return (
    <div className="pointer-events-none fixed bottom-24 left-1/2 z-[120] flex w-[92%] max-w-md -translate-x-1/2 flex-col items-center gap-2 md:bottom-8">
      {toasts.map((t) => (
        <button
          key={t.id}
          onClick={() => dismissToast(t.id)}
          className={cx(
            "toast-in pointer-events-auto flex w-full items-center gap-3 rounded-2xl border-l-4 bg-[color-mix(in_srgb,var(--ink)_96%,black)] px-4 py-3 text-left text-sm text-[var(--bg)] shadow-2xl",
            t.kind === "success" && "border-emerald-400",
            t.kind === "error" && "border-red-400",
            t.kind === "info" && "border-amber-300"
          )}
        >
          {t.kind === "success" && <CheckCircle2 size={17} className="shrink-0 text-emerald-400" />}
          {t.kind === "error" && <AlertTriangle size={17} className="shrink-0 text-red-400" />}
          {t.kind === "info" && <Bell size={17} className="shrink-0 text-amber-300" />}
          <span className="leading-snug">{t.msg}</span>
        </button>
      ))}
    </div>
  );
}
