import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { cx } from "../utils";

/* ------------------------------------------------------------------ */
/* Reveal — animates children into view on scroll                      */
/* ------------------------------------------------------------------ */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setSeen(true);
          io.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -6% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={cx("reveal", seen && "reveal-in", className)}
      style={{ transitionDelay: `${delay}ms`, ["--ry" as string]: `${y}px` }}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* SplitText — per-character staggered entrance for headings           */
/* ------------------------------------------------------------------ */
export function SplitText({
  text,
  className = "",
  charDelay = 26,
  startDelay = 0,
}: {
  text: string;
  className?: string;
  charDelay?: number;
  startDelay?: number;
}) {
  const words = text.split(" ");
  let i = 0;
  return (
    <span className={className} aria-label={text}>
      {words.map((w, wi) => (
        <span key={wi} className="inline-block whitespace-nowrap">
          {[...w].map((c, ci) => {
            const d = startDelay + i++ * charDelay;
            return (
              <span key={ci} className="anim-char" style={{ animationDelay: `${d}ms` }} aria-hidden>
                {c}
              </span>
            );
          })}
          {wi < words.length - 1 ? <span>&nbsp;</span> : null}
        </span>
      ))}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* CountUp — animated number when scrolled into view                   */
/* ------------------------------------------------------------------ */
export function CountUp({ to, suffix = "", duration = 1400 }: { to: number; suffix?: string; duration?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [n, setN] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        io.disconnect();
        const t0 = performance.now();
        const tick = (t: number) => {
          const p = Math.min(1, (t - t0) / duration);
          setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
          if (p < 1) raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
      },
      { threshold: 0.4 }
    );
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [to, duration]);
  return (
    <span ref={ref}>
      {n.toLocaleString("en-IN")}
      {suffix}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Eyebrow — small animated kicker label                               */
/* ------------------------------------------------------------------ */
export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <Reveal>
      <div className="flex items-center gap-3">
        <span className="h-px w-8 bg-accent" />
        <span className="text-[11px] font-semibold uppercase tracking-[0.28em] tx-primary">{children}</span>
      </div>
    </Reveal>
  );
}
