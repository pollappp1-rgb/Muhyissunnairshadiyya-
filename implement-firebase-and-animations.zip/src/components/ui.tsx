import { useEffect, useRef, useState } from "react";
import type { ReactNode, SelectHTMLAttributes } from "react";
import {
  AlertTriangle, Bell, BookOpen, CalendarDays, Clapperboard, Flag, GraduationCap, Heart, Home, Image as ImageIcon,
  Images, Info, Link as LinkIcon, MessagesSquare, Megaphone, Newspaper, PenLine, Plus, ScrollText, Sparkles,
  Star, Trash2, Upload, Users, Video, X, ChevronLeft, ChevronRight,
} from "lucide-react";
import { useSite } from "../store";
import { cx, isDataUrl, processImageFile, fileToDataUrl } from "../utils";

/* ------------------------------------------------------------------ */
/* Icon registry used by editable home buttons                         */
/* ------------------------------------------------------------------ */
export const ICONS = {
  Home, BookOpen, Newspaper, Images, Clapperboard, CalendarDays, Trophy: Star, Users, MessagesSquare,
  Flag, Info, Megaphone, PenLine, Sparkles, Bell, Heart, Video, GraduationCap, ScrollText, Plus,
} as const;

export type IconName = keyof typeof ICONS;

export function IconByName({ name, size = 18, className }: { name: string; size?: number; className?: string }) {
  const Cmp = (ICONS as Record<string, typeof Home>)[name] || LinkIcon;
  return <Cmp size={size} className={className} />;
}

export const ICON_NAMES = Object.keys(ICONS) as IconName[];

/* ------------------------------------------------------------------ */
/* Buttons                                                             */
/* ------------------------------------------------------------------ */
type BtnVariant = "primary" | "outline" | "ghost" | "ink" | "danger" | "accent";
type BtnSize = "sm" | "md" | "lg";

export function Btn({
  variant = "primary", size = "md", className = "", ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: BtnSize }) {
  const variants: Record<BtnVariant, string> = {
    primary: "bg-primary tx-on hover:shadow-xl hover:shadow-[color-mix(in_srgb,var(--primary)_40%,transparent)] hover:-translate-y-0.5",
    outline: "border line tx hover:soft-panel hover:-translate-y-0.5",
    ghost: "tx-soft hover:tx hover:soft-panel",
    ink: "bg-ink text-[var(--bg)] hover:-translate-y-0.5 hover:shadow-xl",
    danger: "bg-red-600 text-white hover:bg-red-500 hover:-translate-y-0.5",
    accent: "bg-accent text-white hover:-translate-y-0.5 hover:shadow-xl",
  };
  const sizes: Record<BtnSize, string> = {
    sm: "text-xs px-4 py-2",
    md: "text-sm px-6 py-3",
    lg: "text-sm md:text-base px-8 py-4",
  };
  return (
    <button
      className={cx(
        "inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:pointer-events-none",
        variants[variant], sizes[size], className
      )}
      {...rest}
    />
  );
}

/* ------------------------------------------------------------------ */
/* Chips / badges                                                      */
/* ------------------------------------------------------------------ */
export function Chip({ children, color, className = "" }: { children: ReactNode; color?: string; className?: string }) {
  return (
    <span
      className={cx("inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-semibold tracking-wide", className)}
      style={
        color
          ? { background: `color-mix(in srgb, ${color} 12%, transparent)`, color }
          : { background: "color-mix(in srgb, var(--ink) 7%, transparent)" }
      }
    >
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Form primitives                                                     */
/* ------------------------------------------------------------------ */
export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between text-xs font-semibold uppercase tracking-[0.14em] tx-faint">
        {label}
        {hint && <span className="text-[10px] normal-case tracking-normal tx-faint">{hint}</span>}
      </span>
      {children}
    </label>
  );
}

const inputCls =
  "w-full rounded-xl border line bg-[var(--surface)] px-4 py-2.5 text-sm outline-none transition focus:border-[var(--primary)] focus:ring-2 focus:ring-[color-mix(in_srgb,var(--primary)_22%,transparent)]";

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cx(inputCls, props.className)} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cx(inputCls, "min-h-[110px] leading-relaxed", props.className)} />;
}

export function SelectInput(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cx(inputCls, "appearance-none", props.className)} />;
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex items-center gap-3">
      <span
        className={cx(
          "relative h-6 w-11 rounded-full transition-colors duration-300",
          checked ? "bg-primary" : "bg-[color-mix(in_srgb,var(--ink)_18%,transparent)]"
        )}
      >
        <span
          className={cx(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all duration-300",
            checked ? "left-[22px]" : "left-0.5"
          )}
        />
      </span>
      {label && <span className="text-sm font-medium">{label}</span>}
    </button>
  );
}

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center gap-3 rounded-xl border line bg-[var(--surface)] px-3 py-2">
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-9 cursor-pointer rounded-full border-0 bg-transparent p-0"
      />
      <div className="min-w-0">
        <div className="text-[11px] font-semibold uppercase tracking-[0.12em] tx-faint">{label}</div>
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-transparent font-mono text-xs outline-none"
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* FileOrLink — upload from internal storage OR paste a link           */
/* ------------------------------------------------------------------ */
export function FileOrLink({
  label, value, onChange, kind = "image", hint, maxMB = 7,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  kind?: "image" | "pdf" | "video" | "any";
  hint?: string;
  maxMB?: number;
}) {
  const { toast } = useSite();
  const ref = useRef<HTMLInputElement>(null);
  const accept = kind === "image" ? "image/*" : kind === "pdf" ? "application/pdf" : kind === "video" ? "video/*" : "*/*";
  const isImg = value.startsWith("data:image") || /\.(png|jpe?g|webp|gif|svg|avif)(\?|$)/i.test(value) || value.startsWith("/images/");

  const pick = async (f: File | undefined) => {
    if (!f) return;
    if (kind !== "image" && f.size > maxMB * 1024 * 1024) {
      toast(`File is larger than ${maxMB}MB — please paste an external link instead.`, "error");
      return;
    }
    try {
      const out = kind === "image" ? await processImageFile(f) : await fileToDataUrl(f);
      onChange(out);
      toast("File attached from device", "success");
    } catch {
      toast("Could not read that file", "error");
    }
  };

  return (
    <Field label={label} hint={hint}>
      <div className="space-y-2">
        {value ? (
          <div className="flex items-center gap-3 rounded-xl border line bg-[var(--surface)] p-2">
            {kind === "image" && isImg ? (
              <img src={value} alt="" className="h-14 w-14 rounded-lg object-cover" />
            ) : (
              <span className="flex h-14 w-14 items-center justify-center rounded-lg soft-panel tx-faint">
                {kind === "pdf" ? <ScrollText size={20} /> : kind === "video" ? <Video size={20} /> : <LinkIcon size={20} />}
              </span>
            )}
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-medium">{isDataUrl(value) ? "Attached from device storage" : value}</div>
              <div className="text-[10px] uppercase tracking-widest tx-faint">{isDataUrl(value) ? "stored in database" : "external link"}</div>
            </div>
            <button type="button" onClick={() => onChange("")} className="rounded-full p-2 text-red-500 hover:bg-red-50">
              <Trash2 size={15} />
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <Btn type="button" variant="outline" size="sm" onClick={() => ref.current?.click()} className="flex-1">
              <Upload size={14} /> Upload
            </Btn>
          </div>
        )}
        {!value && (
          <TextInput
            placeholder={kind === "video" ? "…or paste YouTube / video link" : kind === "pdf" ? "…or paste PDF link" : "…or paste image link"}
            defaultValue=""
            onBlur={(e) => {
              const v = e.target.value.trim();
              if (v) {
                onChange(v);
                e.target.value = "";
              }
            }}
          />
        )}
        <input
          ref={ref}
          type="file"
          accept={accept}
          className="hidden"
          onChange={(e) => {
            void pick(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
      </div>
    </Field>
  );
}

/* ------------------------------------------------------------------ */
/* Modal + Confirm dialog (popup alerts)                               */
/* ------------------------------------------------------------------ */
export function Modal({
  open, onClose, children, wide = false, bare = false,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
  bare?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const fn = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", fn);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", fn);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center p-0 sm:items-center sm:p-6">
      <div className="fade-in absolute inset-0 bg-black/55 backdrop-blur-sm" onClick={onClose} />
      <div
        className={cx(
          "pop-in relative max-h-[92vh] w-full overflow-y-auto no-scrollbar",
          bare ? "" : "rounded-t-[2rem] bg-[var(--surface)] p-6 sm:rounded-[2rem] sm:p-8",
          wide ? "sm:max-w-4xl" : "sm:max-w-lg"
        )}
      >
        {children}
      </div>
    </div>
  );
}

export function CloseBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute right-4 top-4 z-10 rounded-full bg-black/45 p-2 text-white backdrop-blur transition hover:bg-black/70"
      aria-label="Close"
    >
      <X size={16} />
    </button>
  );
}

export function ConfirmDialog({
  open, title, message, onCancel, onConfirm, confirmLabel = "Delete",
}: {
  open: boolean;
  title: string;
  message: string;
  onCancel: () => void;
  onConfirm: () => void;
  confirmLabel?: string;
}) {
  return (
    <Modal open={open} onClose={onCancel}>
      <div className="text-center">
        <span className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-red-50 text-red-500">
          <AlertTriangle size={24} />
        </span>
        <h3 className="font-display text-xl font-semibold">{title}</h3>
        <p className="mt-2 text-sm tx-soft">{message}</p>
        <div className="mt-6 flex justify-center gap-3">
          <Btn variant="ghost" onClick={onCancel}>Cancel</Btn>
          <Btn variant="danger" onClick={onConfirm}>
            <Trash2 size={15} /> {confirmLabel}
          </Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
/* Avatar with graceful initials fallback                              */
/* ------------------------------------------------------------------ */
export function Avatar({ name, photo, sizeClass = "h-12 w-12", textClass = "text-base" }: { name: string; photo?: string; sizeClass?: string; textClass?: string }) {
  const initials = name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();
  if (photo) return <img src={photo} alt={name} className={cx(sizeClass, "rounded-full object-cover ring-2 ring-white/40")} />;
  return (
    <span className={cx(sizeClass, "flex items-center justify-center rounded-full bg-primary font-display font-semibold tx-on ring-2 ring-white/40", textClass)}>
      {initials || "M"}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Image box with placeholder fallback                                 */
/* ------------------------------------------------------------------ */
export function ImgBox({ src, alt = "", className = "", imgClassName = "" }: { src: string; alt?: string; className?: string; imgClassName?: string }) {
  const [err, setErr] = useState(false);
  if (!src || err) {
    return (
      <div className={cx("flex items-center justify-center soft-panel tx-faint", className)}>
        <ImageIcon size={28} strokeWidth={1.5} />
      </div>
    );
  }
  return (
    <div className={cx("overflow-hidden", className)}>
      <img src={src} alt={alt} loading="lazy" onError={() => setErr(true)} className={cx("h-full w-full object-cover", imgClassName)} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Empty state                                                         */
/* ------------------------------------------------------------------ */
export function EmptyState({ icon, title, sub }: { icon: ReactNode; title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-3xl border border-dashed line py-16 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-full soft-panel tx-faint">{icon}</span>
      <p className="font-display text-lg font-semibold">{title}</p>
      {sub && <p className="max-w-xs text-sm tx-faint">{sub}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Lightbox                                                            */
/* ------------------------------------------------------------------ */
export function Lightbox({
  images, index, onClose, onNav,
}: {
  images: string[];
  index: number;
  onClose: () => void;
  onNav: (i: number) => void;
}) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onNav((index + 1) % images.length);
      if (e.key === "ArrowLeft") onNav((index - 1 + images.length) % images.length);
    };
    window.addEventListener("keydown", fn);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", fn);
      document.body.style.overflow = "";
    };
  }, [index, images.length, onClose, onNav]);
  return (
    <div className="fade-in fixed inset-0 z-[100] flex items-center justify-center bg-black/92 p-4 backdrop-blur" onClick={onClose}>
      <img
        src={images[index]}
        alt=""
        className="pop-in max-h-[86vh] max-w-[92vw] rounded-2xl object-contain shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      />
      {images.length > 1 && (
        <>
          <button
            className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white backdrop-blur hover:bg-white/25"
            onClick={(e) => { e.stopPropagation(); onNav((index - 1 + images.length) % images.length); }}
          >
            <ChevronLeft size={20} />
          </button>
          <button
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white backdrop-blur hover:bg-white/25"
            onClick={(e) => { e.stopPropagation(); onNav((index + 1) % images.length); }}
          >
            <ChevronRight size={20} />
          </button>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold text-white backdrop-blur">
            {index + 1} / {images.length}
          </div>
        </>
      )}
      <button className="absolute right-4 top-4 rounded-full bg-white/10 p-2.5 text-white backdrop-blur hover:bg-white/25" onClick={onClose}>
        <X size={18} />
      </button>
    </div>
  );
}
